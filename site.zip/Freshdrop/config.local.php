<?php
declare(strict_types=1);

return [
    'oauth' => [
        'telegram' => [
            'bot_username' => 'authFreshBot',
            'bot_token' => '8716275201:AAFtjDwPuIzpV2X7z7RWYvweWlSQj_3ptnI',
        ],
    ],
];


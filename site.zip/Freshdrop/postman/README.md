# Postman — демонстрация API FreshDrop

## Установка

1. Скачайте [Postman](https://www.postman.com/downloads/) и установите.
2. В Postman: **Import** → выберите файл `Freshdrop_API.postman_collection.json`.
3. В коллекции откройте переменные и при необходимости измените `base_url` (по умолчанию `http://localhost/Freshdrop`).

## Порядок проверки

1. **Auth — клиент (demo)** — POST `/api/auth` с почтой и паролем. Скрипт сохранит `token` в переменные коллекции.
2. **GET /api/menu** — ответ: массив id, например `[1,2,3,...]`.
3. **GET /api/menu/1** — полное описание блюда (описание, состав, цена).
4. **POST /api/client/orders** — тело `[1, 6, 28]` (массив id товаров). Нужен сохранённый адрес у демо-пользователя.
5. **GET /api/client/orders** и **GET /api/client/orders/:id** — список и детали заказа.
6. **DELETE /api/client/orders/:id** — отмена (пока статус «принят» или «готовится»).
7. **Auth — админ** — login `admin`, пароль `admin123` (или из `config.local.php`).
8. Запросы из папки **Admin** — просмотр всех заказов и **PUT** смены статуса (`accepted`, `preparing`, `delivering`, `received`).

## Токен

Передавайте в каждом защищённом запросе:

```
Authorization: Bearer <token>
```

или заголовок `X-Auth-Token: <token>`.

При неверном токене сервер отвечает `401` и JSON `{"error":"Неверный или просроченный токен"}`.

## Демо-аккаунт

| Поле | Значение |
|------|----------|
| Логин | `demo@freshdrop.local` |
| Пароль | `demo123` |

Пароль на сервере хранится в виде bcrypt-хеша; в Postman отправляется обычный пароль, хеширование выполняет сервер.

<?php

declare(strict_types=1);

final class ApiAuth
{
    private const TOKEN_TTL_DAYS = 30;

    public function __construct(
        private \PDO $pdo,
        private array $config,
    ) {}

    /** @return array{role: string, user_id: int|null}|null */
    public function resolveBearer(?string $rawToken): ?array
    {
        if ($rawToken === null || $rawToken === '') {
            return null;
        }
        $hash = hash('sha256', $rawToken);
        $st = $this->pdo->prepare(
            'SELECT role, user_id, expires_at FROM api_tokens WHERE token_hash = ?'
        );
        $st->execute([$hash]);
        $row = $st->fetch();
        if (!$row) {
            return null;
        }
        if (strtotime((string) $row['expires_at']) < time()) {
            $this->pdo->prepare('DELETE FROM api_tokens WHERE token_hash = ?')->execute([$hash]);

            return null;
        }

        return [
            'role' => (string) $row['role'],
            'user_id' => $row['user_id'] !== null ? (int) $row['user_id'] : null,
        ];
    }

    public static function extractTokenFromRequest(): ?string
    {
        $hdr = (string) (
            $_SERVER['HTTP_AUTHORIZATION']
            ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
            ?? ''
        );
        if ($hdr === '' && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['Authorization'])) {
                $hdr = (string) $headers['Authorization'];
            } elseif (isset($headers['authorization'])) {
                $hdr = (string) $headers['authorization'];
            }
        }
        if (preg_match('/^\s*Bearer\s+(\S+)\s*$/i', $hdr, $m)) {
            return $m[1];
        }
        $alt = trim((string) ($_SERVER['HTTP_X_AUTH_TOKEN'] ?? ''));
        if ($alt !== '') {
            return $alt;
        }

        return null;
    }

    /** @return array{token: string, role: string, user_id: int|null}|null */
    public function login(string $login, string $password): ?array
    {
        $login = trim($login);
        if ($login === '' || $password === '') {
            return null;
        }

        if (strcasecmp($login, 'admin') === 0 && $this->verifyAdminPassword($password)) {
            return $this->issueToken('admin', null);
        }

        $email = strtolower($login);
        $st = $this->pdo->prepare('SELECT id, password_hash FROM users WHERE lower(trim(email)) = ?');
        $st->execute([$email]);
        $row = $st->fetch();
        if (!$row) {
            return null;
        }
        $hash = (string) ($row['password_hash'] ?? '');
        if ($hash === '' || !password_verify($password, $hash)) {
            return null;
        }

        return $this->issueToken('client', (int) $row['id']);
    }

    /** @return array{token: string, role: string, user_id: int|null} */
    private function issueToken(string $role, ?int $userId): array
    {
        $plain = bin2hex(random_bytes(32));
        $hash = hash('sha256', $plain);
        $expires = (new \DateTimeImmutable('+' . self::TOKEN_TTL_DAYS . ' days'))->format('Y-m-d H:i:s');
        $st = $this->pdo->prepare(
            'INSERT INTO api_tokens (token_hash, user_id, role, expires_at) VALUES (?, ?, ?, ?)'
        );
        $st->execute([$hash, $userId, $role, $expires]);

        return ['token' => $plain, 'role' => $role, 'user_id' => $userId];
    }

    private function verifyAdminPassword(string $input): bool
    {
        $hash = $this->config['admin_password_hash'] ?? null;
        if (is_string($hash) && $hash !== '') {
            return password_verify($input, $hash);
        }
        $plain = (string) ($this->config['admin_password'] ?? '');

        return $plain !== '' && hash_equals($plain, $input);
    }
}

<?php

declare(strict_types=1);

const PROJECT_ROOT = __DIR__ . '/..';

spl_autoload_register(function (string $class): void {
    $base = PROJECT_ROOT . '/src/';
    $candidates = [
        $base . str_replace('\\', '/', $class) . '.php',
        $base . 'Controllers/' . $class . '.php',
    ];
    foreach ($candidates as $path) {
        if (is_file($path)) {
            require $path;
            return;
        }
    }
});

date_default_timezone_set('Europe/Moscow');

$config = [
    'db_path' => PROJECT_ROOT . '/storage/app.sqlite',
    /** Пароль входа в /admin. Переопределите в config.local.php */
    'admin_password' => 'admin123',
    // OAuth / Telegram auth settings (set real values in config.local.php)
    'oauth' => [
        'vk' => [
            'client_id' => '',
            'client_secret' => '',
        ],
        'yandex' => [
            'client_id' => '',
            'client_secret' => '',
        ],
        'telegram' => [
            'bot_username' => '',
            'bot_token' => '',
        ],
    ],
];

$local = PROJECT_ROOT . '/config.local.php';
if (is_file($local)) {
    $config = array_merge($config, require $local);
}

if (!is_dir(PROJECT_ROOT . '/storage')) {
    mkdir(PROJECT_ROOT . '/storage', 0755, true);
}
if (!is_dir(PROJECT_ROOT . '/storage/avatars')) {
    mkdir(PROJECT_ROOT . '/storage/avatars', 0755, true);
}

return $config;

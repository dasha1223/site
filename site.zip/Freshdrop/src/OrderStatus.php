<?php

declare(strict_types=1);

final class OrderStatus
{
    public const ACCEPTED = 'accepted';
    public const PREPARING = 'preparing';
    public const DELIVERING = 'delivering';
    public const RECEIVED = 'received';
    public const CANCELLED = 'cancelled';

    /** @var list<string> */
    public const ALL = [
        self::ACCEPTED,
        self::PREPARING,
        self::DELIVERING,
        self::RECEIVED,
        self::CANCELLED,
    ];

    /** @var list<string> */
    public const CLIENT_CANCELLABLE = [
        self::ACCEPTED,
        self::PREPARING,
    ];

    public static function normalize(string $status): string
    {
        $s = strtolower(trim($status));

        return match ($s) {
            'new', 'принят', 'accepted' => self::ACCEPTED,
            'cooking', 'preparing', 'готовится' => self::PREPARING,
            'delivering', 'в доставке', 'в пути' => self::DELIVERING,
            'done', 'completed', 'received', 'получен', 'выполнен' => self::RECEIVED,
            'cancelled', 'отменён', 'отменен' => self::CANCELLED,
            default => $s,
        };
    }

    public static function isValid(string $status): bool
    {
        return in_array(self::normalize($status), self::ALL, true);
    }

    public static function labelRu(string $status): string
    {
        return match (self::normalize($status)) {
            self::ACCEPTED => 'принят',
            self::PREPARING => 'Готовят',
            self::DELIVERING => 'Курьер в пути',
            self::RECEIVED => 'Доставлено',
            self::CANCELLED => 'отменён',
            default => $status,
        };
    }

    public static function isActiveDelivery(string $status): bool
    {
        return in_array(self::normalize($status), [
            self::ACCEPTED,
            self::PREPARING,
            self::DELIVERING,
        ], true);
    }

    public static function canClientCancel(string $status): bool
    {
        return in_array(self::normalize($status), self::CLIENT_CANCELLABLE, true);
    }
}

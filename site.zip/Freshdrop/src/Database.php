<?php

declare(strict_types=1);

final class Database
{
    private static ?\PDO $pdo = null;

    public static function pdo(string $dbPath): \PDO
    {
        if (self::$pdo === null) {
            $dsn = 'sqlite:' . $dbPath;
            self::$pdo = new \PDO($dsn, null, null, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            ]);
            self::$pdo->exec('PRAGMA foreign_keys = ON');
        }
        return self::$pdo;
    }

    public static function resetForTests(): void
    {
        self::$pdo = null;
    }
}

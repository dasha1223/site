<?php

declare(strict_types=1);

final class OrderProgress
{
    public const STAGE_MINUTES = 15;

    public static function syncActiveOrders(\PDO $pdo): void
    {
        $st = $pdo->query(
            "SELECT id, status, placed_at, created_at FROM orders
             WHERE status IN ('accepted', 'preparing', 'delivering')"
        );
        foreach ($st->fetchAll() as $row) {
            self::syncOne(
                $pdo,
                (int) $row['id'],
                (string) $row['status'],
                (int) ($row['placed_at'] ?? 0),
                (string) ($row['created_at'] ?? '')
            );
        }
    }

    public static function syncOne(
        \PDO $pdo,
        int $orderId,
        string $status,
        int $placedAt = 0,
        string $createdAt = '',
    ): void {
        $status = OrderStatus::normalize($status);
        $placedAt = self::resolvePlacedAt($pdo, $orderId, $placedAt, $createdAt);
        $elapsedMin = (int) floor((time() - $placedAt) / 60);

        $target = self::statusForElapsed($elapsedMin);

        if ($status === OrderStatus::CANCELLED) {
            return;
        }

        if ($target !== $status) {
            $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$target, $orderId]);
        }
    }

    private static function statusForElapsed(int $elapsedMin): string
    {
        return match (true) {
            $elapsedMin >= self::STAGE_MINUTES * 2 => OrderStatus::RECEIVED,
            $elapsedMin >= self::STAGE_MINUTES => OrderStatus::DELIVERING,
            default => OrderStatus::PREPARING,
        };
    }

    private static function resolvePlacedAt(\PDO $pdo, int $orderId, int $placedAt, string $createdAt): int
    {
        if ($placedAt > 0) {
            return $placedAt;
        }
        $ts = strtotime($createdAt);
        $placedAt = ($ts !== false && $createdAt !== '') ? $ts : time();
        $pdo->prepare('UPDATE orders SET placed_at = ? WHERE id = ?')->execute([$placedAt, $orderId]);

        return $placedAt;
    }

    /** @return list<array<string,mixed>> */
    public static function timeline(string $status): array
    {
        $status = OrderStatus::normalize($status);
        $steps = [
            ['key' => OrderStatus::PREPARING, 'label' => 'Готовят'],
            ['key' => OrderStatus::DELIVERING, 'label' => 'Курьер в пути'],
            ['key' => OrderStatus::RECEIVED, 'label' => 'Доставлено'],
        ];

        if ($status === OrderStatus::CANCELLED) {
            return array_map(static fn ($s) => [
                'key' => $s['key'],
                'label' => $s['label'],
                'done' => false,
                'active' => false,
            ], $steps);
        }

        if ($status === OrderStatus::RECEIVED) {
            return array_map(static fn ($s) => [
                'key' => $s['key'],
                'label' => $s['label'],
                'done' => true,
                'active' => false,
            ], $steps);
        }

        $order = [OrderStatus::PREPARING, OrderStatus::DELIVERING, OrderStatus::RECEIVED];
        $idx = array_search($status, $order, true);
        if ($status === OrderStatus::ACCEPTED || $idx === false) {
            $idx = 0;
        }

        $out = [];
        foreach ($steps as $i => $step) {
            $out[] = [
                'key' => $step['key'],
                'label' => $step['label'],
                'done' => $i < $idx,
                'active' => $i === $idx,
            ];
        }

        return $out;
    }

    public static function etaMinutes(string $status, int $placedAt): int
    {
        $status = OrderStatus::normalize($status);
        if ($placedAt < 1) {
            return self::STAGE_MINUTES * 2;
        }
        $elapsed = max(0, (int) floor((time() - $placedAt) / 60));
        if ($status === OrderStatus::RECEIVED || $status === OrderStatus::CANCELLED) {
            return 0;
        }

        return max(0, self::STAGE_MINUTES * 2 - $elapsed);
    }
}

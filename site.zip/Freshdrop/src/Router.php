<?php

declare(strict_types=1);

final class Router
{
    /** @var array<string, array<string, callable>> */
    private array $routes = [];

    public function get(string $pattern, callable $handler): self
    {
        $this->routes['GET'][$pattern] = $handler;
        return $this;
    }

    public function post(string $pattern, callable $handler): self
    {
        $this->routes['POST'][$pattern] = $handler;
        return $this;
    }

    public function put(string $pattern, callable $handler): self
    {
        $this->routes['PUT'][$pattern] = $handler;
        return $this;
    }

    public function delete(string $pattern, callable $handler): self
    {
        $this->routes['DELETE'][$pattern] = $handler;
        return $this;
    }

    public function dispatch(string $method, string $path): void
    {
        $path = rtrim($path, '/') ?: '/';

        $routes = $this->routes[$method] ?? [];
        foreach ($routes as $pattern => $handler) {
            $regex = $this->patternToRegex($pattern);
            if (preg_match($regex, $path, $m)) {
                $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
                $handler(...array_values($params));
                return;
            }
        }
        Response::error('NOT_FOUND', 'Маршрут не найден', 404);
    }

    private function patternToRegex(string $pattern): string
    {
        $pattern = rtrim($pattern, '/') ?: '/';
        $parts = preg_replace_callback('/\{([a-z_]+)\}/', static fn ($m) => '(?P<' . $m[1] . '>[^/]+)', $pattern);
        return '#^' . $parts . '$#';
    }
}

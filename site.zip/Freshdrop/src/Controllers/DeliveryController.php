<?php

declare(strict_types=1);

final class DeliveryController
{
    public function __construct(private \PDO $pdo) {}

    public function zones(): void
    {
        $rows = $this->pdo->query(
            'SELECT id, name, min_order_cents, delivery_fee_cents FROM delivery_zones ORDER BY id'
        )->fetchAll();
        $zones = array_map(static function (array $z): array {
            return [
                'id' => (int) $z['id'],
                'name' => $z['name'],
                'min_order' => (int) $z['min_order_cents'] / 100,
                'min_order_cents' => (int) $z['min_order_cents'],
                'delivery_fee' => (int) $z['delivery_fee_cents'] / 100,
                'delivery_fee_cents' => (int) $z['delivery_fee_cents'],
            ];
        }, $rows);
        Response::success(['zones' => $zones]);
    }
}

<?php

declare(strict_types=1);

final class AdminController
{
    public function __construct(
        private \PDO $pdo,
        private array $config,
    ) {}

    public function showPage(): void
    {
        $this->ensureSession();
        header('Content-Type: text/html; charset=utf-8');

        $error = $_SESSION['admin_login_error'] ?? null;
        unset($_SESSION['admin_login_error']);

        if (empty($_SESSION['admin_ok'])) {
            $adminLoginUrl = $this->adminUrl('/admin/login');
            $siteHomeUrl = $this->adminUrl('/');
            require PROJECT_ROOT . '/views/admin_login.php';
            return;
        }

        $orders = $this->fetchOrdersWithItems();
        require PROJECT_ROOT . '/views/admin_dashboard.php';
    }

    public function login(): void
    {
        $this->ensureSession();
        $pwd = (string) ($_POST['password'] ?? '');
        if ($this->verifyPassword($pwd)) {
            $_SESSION['admin_ok'] = true;
            header('Location: ' . $this->adminUrl('/admin'), true, 302);
            exit;
        }
        $_SESSION['admin_login_error'] = 'Неверный пароль';
        header('Location: ' . $this->adminUrl('/admin'), true, 302);
        exit;
    }

    public function logout(): void
    {
        $this->ensureSession();
        unset($_SESSION['admin_ok'], $_SESSION['admin_login_error']);
        header('Location: ' . $this->adminUrl('/admin'), true, 302);
        exit;
    }

    public function updateOrderStatus(int $orderId): void
    {
        $this->ensureSession();
        if (empty($_SESSION['admin_ok'])) {
            header('Location: ' . $this->adminUrl('/admin'), true, 302);
            exit;
        }
        $status = OrderStatus::normalize((string) ($_POST['status'] ?? ''));
        if (!OrderStatus::isValid($status) || $status === OrderStatus::CANCELLED) {
            $_SESSION['admin_login_error'] = 'Некорректный статус';
            header('Location: ' . $this->adminUrl('/admin'), true, 302);
            exit;
        }
        $st = $this->pdo->prepare('SELECT id FROM orders WHERE id = ?');
        $st->execute([$orderId]);
        if (!$st->fetch()) {
            $_SESSION['admin_login_error'] = 'Заказ не найден';
            header('Location: ' . $this->adminUrl('/admin'), true, 302);
            exit;
        }
        $this->pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $orderId]);
        header('Location: ' . $this->adminUrl('/admin'), true, 302);
        exit;
    }

    private function verifyPassword(string $input): bool
    {
        $hash = $this->config['admin_password_hash'] ?? null;
        if (is_string($hash) && $hash !== '') {
            return password_verify($input, $hash);
        }
        $plain = (string) ($this->config['admin_password'] ?? '');
        return $plain !== '' && hash_equals($plain, $input);
    }

    /** @return list<array<string, mixed>> */
    private function fetchOrdersWithItems(): array
    {
        $rows = $this->pdo->query(
            'SELECT id, customer_name, phone, address, comment, status, total_cents, created_at
             FROM orders ORDER BY id DESC LIMIT 200'
        )->fetchAll();

        $st = $this->pdo->prepare(
            'SELECT d.name AS dish_name, oi.quantity, oi.price_cents
             FROM order_items oi
             JOIN dishes d ON d.id = oi.dish_id
             WHERE oi.order_id = ?
             ORDER BY oi.id'
        );

        foreach ($rows as &$r) {
            $st->execute([(int) $r['id']]);
            $r['items'] = $st->fetchAll();
        }
        unset($r);

        return $rows;
    }

    private function ensureSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    private function adminUrl(string $path): string
    {
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        $p = '/' . ltrim($path, '/');
        if ($base === '') {
            return $p;
        }
        return $base . $p;
    }
}

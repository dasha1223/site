<?php

declare(strict_types=1);

final class GeocodeController
{
    /** Default: центр Москвы */
    private const DEFAULT_LAT = 55.7558;
    private const DEFAULT_LNG = 37.6173;

    public function geocode(): void
    {
        $address = trim((string) ($_GET['address'] ?? ''));
        if ($address === '') {
            Response::error('VALIDATION', 'Укажите адрес', 422);
            return;
        }

        $result = $this->fetchNominatim($address . ', Россия');
        if ($result === null) {
            Response::success([
                'found' => false,
                'lat' => self::DEFAULT_LAT,
                'lng' => self::DEFAULT_LNG,
                'display_name' => $address,
            ]);
            return;
        }

        Response::success([
            'found' => true,
            'lat' => $result['lat'],
            'lng' => $result['lng'],
            'display_name' => $result['display_name'],
        ]);
    }

    /** @return array{lat: float, lng: float, display_name: string}|null */
    private function fetchNominatim(string $query): ?array
    {
        $url = 'https://nominatim.openstreetmap.org/search?'
            . http_build_query([
                'format' => 'json',
                'limit' => 1,
                'q' => $query,
            ]);

        $ctx = stream_context_create([
            'http' => [
                'timeout' => 6,
                'header' => "User-Agent: FreshDrop/1.0 (local delivery demo)\r\n",
            ],
        ]);

        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) {
            return null;
        }

        try {
            $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return null;
        }

        if (!is_array($data) || $data === []) {
            return null;
        }

        $first = $data[0];
        if (!isset($first['lat'], $first['lon'])) {
            return null;
        }

        return [
            'lat' => (float) $first['lat'],
            'lng' => (float) $first['lon'],
            'display_name' => (string) ($first['display_name'] ?? $query),
        ];
    }
}

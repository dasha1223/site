<?php

declare(strict_types=1);

final class ApiController
{
    private ApiAuth $auth;

    public function __construct(
        private \PDO $pdo,
        private array $config,
    ) {
        $this->auth = new ApiAuth($pdo, $config);
    }

    public function dispatch(string $method, string $path): void
    {
        $path = rtrim($path, '/') ?: '/';

        if ($path === '/api/auth' && $method === 'POST') {
            $this->authLogin();
            return;
        }

        if ($path === '/api/menu' && $method === 'GET') {
            $this->menuIds();
            return;
        }
        if (preg_match('#^/api/menu/(\d+)$#', $path, $m) && $method === 'GET') {
            $this->menuOne((int) $m[1]);
            return;
        }

        if ($path === '/api/client/orders' && $method === 'GET') {
            $this->clientOrderIds();
            return;
        }
        if ($path === '/api/client/orders' && $method === 'POST') {
            $this->clientCreateOrder();
            return;
        }
        if (preg_match('#^/api/client/orders/(\d+)$#', $path, $m) && $method === 'GET') {
            $this->clientOrderOne((int) $m[1]);
            return;
        }
        if (preg_match('#^/api/client/orders/(\d+)$#', $path, $m) && $method === 'DELETE') {
            $this->cancelOrder((int) $m[1], true);
            return;
        }

        if ($path === '/api/admin/orders' && $method === 'GET') {
            $this->adminOrderIds();
            return;
        }
        if (preg_match('#^/api/admin/orders/(\d+)$#', $path, $m) && $method === 'GET') {
            $this->clientOrderOne((int) $m[1], true);
            return;
        }
        if (preg_match('#^/api/admin/orders/(\d+)$#', $path, $m) && $method === 'PUT') {
            $this->adminUpdateStatus((int) $m[1]);
            return;
        }
        if (preg_match('#^/api/admin/orders/(\d+)$#', $path, $m) && $method === 'DELETE') {
            $this->cancelOrder((int) $m[1], false);
            return;
        }

        $this->apiError('Маршрут не найден', 404);
    }

    private function authLogin(): void
    {
        $body = $this->readJson();
        $login = trim((string) ($body['login'] ?? $body['email'] ?? ''));
        $password = (string) ($body['password'] ?? '');
        $result = $this->auth->login($login, $password);
        if ($result === null) {
            $this->apiError('Неверный логин или пароль', 401);
            return;
        }
        $this->apiJson([
            'token' => $result['token'],
            'role' => $result['role'],
            'user_id' => $result['user_id'],
        ]);
    }

    private function menuIds(): void
    {
        $rows = $this->pdo->query('SELECT id FROM dishes WHERE is_available = 1 ORDER BY id')->fetchAll();
        $this->apiJson(array_map(static fn ($r) => (int) $r['id'], $rows));
    }

    private function menuOne(int $id): void
    {
        $dish = $this->fetchDish($id);
        if ($dish === null) {
            $this->apiError('Товар не найден', 404);
            return;
        }
        $this->apiJson($dish);
    }

    private function clientOrderIds(): void
    {
        $userId = $this->requireClient();
        if ($userId === null) {
            return;
        }
        $st = $this->pdo->prepare('SELECT id FROM orders WHERE user_id = ? ORDER BY id DESC');
        $st->execute([$userId]);
        $this->apiJson(array_map(static fn ($r) => (int) $r['id'], $st->fetchAll()));
    }

    private function clientOrderOne(int $id, bool $adminBypass = false): void
    {
        if (!$adminBypass) {
            $userId = $this->requireClient();
            if ($userId === null) {
                return;
            }
            $order = $this->fetchOrder($id);
            if ($order === null) {
                $this->apiError('Заказ не найден', 404);
                return;
            }
            if ((int) ($order['user_id'] ?? 0) !== $userId) {
                $this->apiError('Доступ запрещён', 403);
                return;
            }
            $this->apiJson($order);
            return;
        }
        if (!$this->requireAdmin()) {
            return;
        }
        $order = $this->fetchOrder($id);
        if ($order === null) {
            $this->apiError('Заказ не найден', 404);
            return;
        }
        $this->apiJson($order);
    }

    private function clientCreateOrder(): void
    {
        $userId = $this->requireClient();
        if ($userId === null) {
            return;
        }

        $body = $this->readJson();
        $dishIds = $body;
        if (isset($body['items']) && is_array($body['items'])) {
            $dishIds = $body['items'];
        }
        if (!is_array($dishIds) || $dishIds === []) {
            $this->apiError('Передайте массив id товаров', 422);
            return;
        }

        $counts = [];
        foreach ($dishIds as $rawId) {
            $id = (int) $rawId;
            if ($id < 1) {
                $this->apiError('Некорректный id товара', 422);
                return;
            }
            $counts[$id] = ($counts[$id] ?? 0) + 1;
        }

        $userSt = $this->pdo->prepare(
            'SELECT display_name, saved_delivery_name, saved_delivery_phone, saved_delivery_address, saved_delivery_comment
             FROM users WHERE id = ?'
        );
        $userSt->execute([$userId]);
        $user = $userSt->fetch();
        if (!$user) {
            $this->apiError('Пользователь не найден', 404);
            return;
        }

        $name = trim((string) ($body['customer_name'] ?? $user['saved_delivery_name'] ?? $user['display_name'] ?? ''));
        $phone = OrderController::normalizePhoneRu((string) ($body['phone'] ?? $user['saved_delivery_phone'] ?? ''));
        $address = trim((string) ($body['address'] ?? $user['saved_delivery_address'] ?? ''));
        $comment = trim((string) ($body['comment'] ?? $user['saved_delivery_comment'] ?? ''));

        if ($name === '' || $address === '') {
            $this->apiError('Укажите имя и адрес (в профиле или в теле запроса)', 422);
            return;
        }
        if ($phone === '' || !preg_match('/^\+7\d{10}$/', $phone)) {
            $this->apiError('Укажите корректный телефон', 422);
            return;
        }

        $lines = [];
        $itemsTotal = 0;
        foreach ($counts as $dishId => $qty) {
            $st = $this->pdo->prepare(
                'SELECT id, price_cents, is_available FROM dishes WHERE id = ?'
            );
            $st->execute([$dishId]);
            $dish = $st->fetch();
            if (!$dish || !(int) $dish['is_available']) {
                $this->apiError('Товар недоступен: ' . $dishId, 422);
                return;
            }
            $price = (int) $dish['price_cents'];
            $lines[] = ['dish_id' => $dishId, 'quantity' => $qty, 'price_cents' => $price];
            $itemsTotal += $price * $qty;
        }

        $zoneId = (int) ($body['delivery_zone_id'] ?? 0);
        $zone = $this->resolveDeliveryZone($zoneId);
        if ($zone === null) {
            $this->apiError('Выберите корректную зону доставки', 422);
            return;
        }
        if ($itemsTotal < (int) $zone['min_order_cents']) {
            $this->apiError('Минимальная сумма заказа для выбранной зоны не достигнута', 422);
            return;
        }
        $deliveryFee = (int) $zone['delivery_fee_cents'];
        $total = $itemsTotal + $deliveryFee;

        try {
            $this->pdo->beginTransaction();
            $ins = $this->pdo->prepare(
                'INSERT INTO orders (user_id, customer_name, phone, address, comment, delivery_zone_id, items_total_cents, delivery_fee_cents, status, total_cents)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $ins->execute([
                $userId,
                $name,
                $phone,
                $address,
                $comment !== '' ? $comment : null,
                (int) $zone['id'],
                $itemsTotal,
                $deliveryFee,
                OrderStatus::ACCEPTED,
                $total,
            ]);
            $orderId = (int) $this->pdo->lastInsertId();
            $itemSt = $this->pdo->prepare(
                'INSERT INTO order_items (order_id, dish_id, quantity, price_cents) VALUES (?, ?, ?, ?)'
            );
            foreach ($lines as $l) {
                $itemSt->execute([$orderId, $l['dish_id'], $l['quantity'], $l['price_cents']]);
            }
            $this->pdo->commit();
        } catch (\Throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            $this->apiError('Не удалось создать заказ', 500);
            return;
        }

        $order = $this->fetchOrder($orderId);
        $this->apiJson($order ?? ['id' => $orderId], 201);
    }

    private function cancelOrder(int $id, bool $clientOnly): void
    {
        if ($clientOnly) {
            $userId = $this->requireClient();
            if ($userId === null) {
                return;
            }
            $st = $this->pdo->prepare('SELECT user_id, status FROM orders WHERE id = ?');
            $st->execute([$id]);
            $row = $st->fetch();
            if (!$row) {
                $this->apiError('Заказ не найден', 404);
                return;
            }
            if ((int) ($row['user_id'] ?? 0) !== $userId) {
                $this->apiError('Доступ запрещён', 403);
                return;
            }
            if (!OrderStatus::canClientCancel((string) $row['status'])) {
                $this->apiError('Заказ нельзя отменить в текущем статусе', 422);
                return;
            }
        } else {
            if (!$this->requireAdmin()) {
                return;
            }
            $st = $this->pdo->prepare('SELECT status FROM orders WHERE id = ?');
            $st->execute([$id]);
            if (!$st->fetch()) {
                $this->apiError('Заказ не найден', 404);
                return;
            }
        }

        $this->pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')
            ->execute([OrderStatus::CANCELLED, $id]);
        $order = $this->fetchOrder($id);
        $this->apiJson($order ?? ['id' => $id, 'status' => OrderStatus::CANCELLED]);
    }

    private function adminOrderIds(): void
    {
        if (!$this->requireAdmin()) {
            return;
        }
        $rows = $this->pdo->query('SELECT id FROM orders ORDER BY id DESC')->fetchAll();
        $this->apiJson(array_map(static fn ($r) => (int) $r['id'], $rows));
    }

    private function adminUpdateStatus(int $id): void
    {
        if (!$this->requireAdmin()) {
            return;
        }
        $body = $this->readJson();
        $status = OrderStatus::normalize((string) ($body['status'] ?? ''));
        if (!OrderStatus::isValid($status) || $status === OrderStatus::CANCELLED) {
            $this->apiError('Укажите статус: accepted, preparing, delivering, received', 422);
            return;
        }
        $st = $this->pdo->prepare('SELECT id FROM orders WHERE id = ?');
        $st->execute([$id]);
        if (!$st->fetch()) {
            $this->apiError('Заказ не найден', 404);
            return;
        }
        $this->pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $id]);
        $order = $this->fetchOrder($id);
        $this->apiJson($order ?? ['id' => $id, 'status' => $status]);
    }

    private function requireClient(): ?int
    {
        $ctx = $this->resolveToken();
        if ($ctx === null) {
            return null;
        }
        if ($ctx['role'] !== 'client' || ($ctx['user_id'] ?? 0) < 1) {
            $this->apiError('Требуется токен клиента', 403);
            return null;
        }

        return (int) $ctx['user_id'];
    }

    private function requireAdmin(): bool
    {
        $ctx = $this->resolveToken();
        if ($ctx === null) {
            return false;
        }
        if ($ctx['role'] !== 'admin') {
            $this->apiError('Требуется токен администратора', 403);
            return false;
        }

        return true;
    }

    /** @return array{role: string, user_id: int|null}|null */
    private function resolveToken(): ?array
    {
        $token = ApiAuth::extractTokenFromRequest();
        if ($token === null) {
            $this->apiError('Токен не передан', 401);
            return null;
        }
        $ctx = $this->auth->resolveBearer($token);
        if ($ctx === null) {
            $this->apiError('Неверный или просроченный токен', 401);
            return null;
        }

        return $ctx;
    }

    /** @return array<string, mixed>|null */
    private function fetchDish(int $id): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT d.id, d.category_id, d.name, d.description, d.composition, d.price_cents, d.image_url,
                    d.is_available, c.name AS category_name
             FROM dishes d JOIN categories c ON c.id = d.category_id WHERE d.id = ?'
        );
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) {
            return null;
        }

        return [
            'id' => (int) $row['id'],
            'category_id' => (int) $row['category_id'],
            'category_name' => $row['category_name'],
            'name' => $row['name'],
            'description' => $row['description'],
            'composition' => $row['composition'],
            'price' => (int) $row['price_cents'] / 100,
            'price_cents' => (int) $row['price_cents'],
            'image_url' => $this->assetUrl((string) $row['image_url']),
            'images' => $this->dishGallery((int) $row['id']),
            'is_available' => (bool) (int) $row['is_available'],
        ];
    }

    /** @return array<string, mixed>|null */
    private function fetchOrder(int $id): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT o.id, o.user_id, o.customer_name, o.phone, o.address, o.comment, o.status, o.total_cents,
                    o.items_total_cents, o.delivery_fee_cents, o.delivery_zone_id, o.created_at, dz.name AS delivery_zone_name
             FROM orders o
             LEFT JOIN delivery_zones dz ON dz.id = o.delivery_zone_id
             WHERE o.id = ?'
        );
        $st->execute([$id]);
        $o = $st->fetch();
        if (!$o) {
            return null;
        }
        $it = $this->pdo->prepare(
            'SELECT oi.dish_id, oi.quantity, oi.price_cents, d.name AS dish_name
             FROM order_items oi JOIN dishes d ON d.id = oi.dish_id WHERE oi.order_id = ?'
        );
        $it->execute([$id]);
        $items = [];
        foreach ($it->fetchAll() as $row) {
            $items[] = [
                'dish_id' => (int) $row['dish_id'],
                'dish_name' => $row['dish_name'],
                'quantity' => (int) $row['quantity'],
                'price_cents' => (int) $row['price_cents'],
            ];
        }

        return [
            'id' => (int) $o['id'],
            'user_id' => $o['user_id'] !== null ? (int) $o['user_id'] : null,
            'customer_name' => $o['customer_name'],
            'phone' => $o['phone'],
            'address' => $o['address'],
            'comment' => $o['comment'],
            'delivery_zone_id' => isset($o['delivery_zone_id']) ? (int) $o['delivery_zone_id'] : null,
            'delivery_zone_name' => $o['delivery_zone_name'] ?? null,
            'status' => OrderStatus::normalize((string) $o['status']),
            'status_label' => OrderStatus::labelRu((string) $o['status']),
            'items_total_cents' => (int) $o['items_total_cents'],
            'delivery_fee_cents' => (int) $o['delivery_fee_cents'],
            'total' => (int) $o['total_cents'] / 100,
            'total_cents' => (int) $o['total_cents'],
            'created_at' => $o['created_at'],
            'items' => $items,
        ];
    }

    /** @return list<string> */
    private function dishGallery(int $dishId): array
    {
        $st = $this->pdo->prepare('SELECT image_url FROM dish_images WHERE dish_id = ? ORDER BY sort_order, id');
        $st->execute([$dishId]);
        $images = [];
        foreach ($st->fetchAll() as $row) {
            $url = $this->assetUrl((string) ($row['image_url'] ?? ''));
            if ($url !== '') {
                $images[] = $url;
            }
        }

        return $images;
    }

    /** @return array<string,mixed>|null */
    private function resolveDeliveryZone(int $zoneId): ?array
    {
        if ($zoneId > 0) {
            $st = $this->pdo->prepare('SELECT id, name, min_order_cents, delivery_fee_cents FROM delivery_zones WHERE id = ?');
            $st->execute([$zoneId]);
            $row = $st->fetch();

            return $row ?: null;
        }
        $row = $this->pdo->query(
            'SELECT id, name, min_order_cents, delivery_fee_cents FROM delivery_zones ORDER BY id LIMIT 1'
        )->fetch();

        return $row ?: null;
    }

    private function assetUrl(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $raw)) {
            return $raw;
        }
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

        return ($base === '' ? '' : $base . '/') . ltrim($raw, '/');
    }

    /** @return array<string, mixed> */
    private function readJson(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') {
            return [];
        }
        try {
            $decoded = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            $this->apiError('Некорректный JSON', 400);
        }

        return is_array($decoded) ? $decoded : [];
    }

    private function apiJson(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private function apiError(string $message, int $status): never
    {
        $this->apiJson(['error' => $message], $status);
        exit;
    }
}

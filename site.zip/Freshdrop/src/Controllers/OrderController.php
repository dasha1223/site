<?php

declare(strict_types=1);

final class OrderController
{
    public function __construct(private \PDO $pdo) {}

    public function create(): void
    {
        $raw = file_get_contents('php://input') ?: '';
        try {
            $body = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            Response::error('INVALID_JSON', 'Некорректный JSON', 400);
            return;
        }

        $name = trim((string) ($body['customer_name'] ?? ''));
        $phone = self::normalizePhoneRu((string) ($body['phone'] ?? ''));
        $address = trim((string) ($body['address'] ?? ''));
        $comment = trim((string) ($body['comment'] ?? ''));
        $zoneId = (int) ($body['delivery_zone_id'] ?? 0);
        $lat = isset($body['address_lat']) ? (float) $body['address_lat'] : null;
        $lng = isset($body['address_lng']) ? (float) $body['address_lng'] : null;
        $items = $body['items'] ?? null;

        if ($name === '' || $address === '') {
            Response::error('VALIDATION', 'Укажите имя и адрес', 422);
            return;
        }
        if ($phone === '' || !preg_match('/^\+7\d{10}$/', $phone)) {
            Response::error('VALIDATION', 'Введите корректный номер телефона (10 цифр после +7)', 422);
            return;
        }
        if (!is_array($items) || $items === []) {
            Response::error('VALIDATION', 'Добавьте позиции в заказ', 422);
            return;
        }

        $lines = [];
        $itemsTotal = 0;
        foreach ($items as $line) {
            if (!is_array($line)) {
                Response::error('VALIDATION', 'Некорректная позиция заказа', 422);
                return;
            }
            $dishId = (int) ($line['dish_id'] ?? 0);
            $qty = (int) ($line['quantity'] ?? 0);
            if ($dishId < 1 || $qty < 1) {
                Response::error('VALIDATION', 'Укажите dish_id и quantity', 422);
                return;
            }
            $st = $this->pdo->prepare(
                'SELECT id, price_cents, is_available FROM dishes WHERE id = ?'
            );
            $st->execute([$dishId]);
            $dish = $st->fetch();
            if (!$dish || !(int) $dish['is_available']) {
                Response::error('DISH_UNAVAILABLE', 'Блюдо недоступно: ' . $dishId, 422);
                return;
            }
            $price = (int) $dish['price_cents'];
            $lines[] = ['dish_id' => $dishId, 'quantity' => $qty, 'price_cents' => $price];
            $itemsTotal += $price * $qty;
        }

        $zone = $this->resolveDeliveryZone($zoneId);
        if ($zone === null) {
            Response::error('VALIDATION', 'Выберите корректную зону доставки', 422);
            return;
        }
        if ($itemsTotal < (int) $zone['min_order_cents']) {
            Response::error(
                'VALIDATION',
                'Минимальная сумма заказа для зоны "' . $zone['name'] . '" — '
                    . number_format(((int) $zone['min_order_cents']) / 100, 0, ',', ' ') . ' ₽',
                422
            );
            return;
        }
        $deliveryFee = (int) $zone['delivery_fee_cents'];
        $total = $itemsTotal + $deliveryFee;

        $sessionUserId = self::sessionUserId($this->pdo);

        $placedAt = time();

        try {
            $this->pdo->beginTransaction();
            $st = $this->pdo->prepare(
                'INSERT INTO orders (user_id, customer_name, phone, address, address_lat, address_lng, comment, delivery_zone_id, items_total_cents, delivery_fee_cents, status, total_cents, placed_at, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\'))'
            );
            $st->execute([
                $sessionUserId > 0 ? $sessionUserId : null,
                $name,
                $phone,
                $address,
                $lat,
                $lng,
                $comment !== '' ? $comment : null,
                (int) $zone['id'],
                $itemsTotal,
                $deliveryFee,
                OrderStatus::PREPARING,
                $total,
                $placedAt,
            ]);
            $orderId = (int) $this->pdo->lastInsertId();

            $itemSt = $this->pdo->prepare(
                'INSERT INTO order_items (order_id, dish_id, quantity, price_cents) VALUES (?, ?, ?, ?)'
            );
            foreach ($lines as $l) {
                $itemSt->execute([
                    $orderId,
                    $l['dish_id'],
                    $l['quantity'],
                    $l['price_cents'],
                ]);
            }
            if ($sessionUserId > 0) {
                $up = $this->pdo->prepare(
                    'UPDATE users SET saved_delivery_name = ?, saved_delivery_phone = ?, saved_delivery_address = ?, saved_delivery_comment = ?
                     WHERE id = ?'
                );
                $up->execute([
                    $name,
                    $phone,
                    $address,
                    $comment !== '' ? $comment : null,
                    $sessionUserId,
                ]);
            }
            $this->pdo->commit();
        } catch (\Throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            Response::error('SERVER', 'Не удалось сохранить заказ', 500);
            return;
        }

        Response::success($this->getOrderPayload($orderId), 201);
    }

    public function one(string $id): void
    {
        $payload = $this->getOrderPayload((int) $id);
        if ($payload === null) {
            Response::error('NOT_FOUND', 'Заказ не найден', 404);
            return;
        }
        Response::success($payload);
    }

    public function byPhone(): void
    {
        $phone = self::normalizePhoneRu((string) ($_GET['phone'] ?? ''));
        if ($phone === '' || !preg_match('/^\+7\d{10}$/', $phone)) {
            Response::error('VALIDATION', 'Укажите корректный query-параметр phone', 422);
            return;
        }
        $st = $this->pdo->prepare(
            'SELECT id FROM orders WHERE phone = ? ORDER BY id DESC LIMIT 50'
        );
        $st->execute([$phone]);
        $ids = array_map(static fn ($r) => (int) $r['id'], $st->fetchAll());
        $orders = [];
        foreach ($ids as $oid) {
            $p = $this->getOrderPayload($oid);
            if ($p) {
                $orders[] = $p;
            }
        }
        Response::success(['orders' => $orders]);
    }

    public function meDeliveryPrefs(): void
    {
        $user = AuthController::currentUser($this->pdo);
        if (!$user) {
            Response::error('UNAUTHORIZED', 'Войдите, чтобы подставить сохранённые данные доставки', 401);
            return;
        }
        Response::success([
            'customer_name' => (string) ($user['saved_delivery_name'] ?? ''),
            'phone' => (string) ($user['saved_delivery_phone'] ?? ''),
            'address' => (string) ($user['saved_delivery_address'] ?? ''),
            'comment' => (string) ($user['saved_delivery_comment'] ?? ''),
        ]);
    }

    public function meOrders(): void
    {
        $user = AuthController::currentUser($this->pdo);
        if (!$user) {
            Response::error('UNAUTHORIZED', 'Войдите, чтобы видеть свои заказы', 401);
            return;
        }
        Response::success(['orders' => $this->listForUser((int) $user['id'])]);
    }

    public function meActiveOrder(): void
    {
        $user = AuthController::currentUser($this->pdo);
        if (!$user) {
            Response::error('UNAUTHORIZED', 'Войдите в профиль', 401);
            return;
        }
        OrderProgress::syncActiveOrders($this->pdo);
        $active = $this->findActiveOrderForUser((int) $user['id']);
        Response::success(['order' => $active]);
    }

    /** @return array{ok: bool, message: string} */
    public function cancelByUser(int $orderId, int $userId): array
    {
        $st = $this->pdo->prepare('SELECT user_id, status FROM orders WHERE id = ?');
        $st->execute([$orderId]);
        $row = $st->fetch();
        if (!$row) {
            return ['ok' => false, 'message' => 'Заказ не найден'];
        }
        if ((int) ($row['user_id'] ?? 0) !== $userId) {
            return ['ok' => false, 'message' => 'Нет доступа к этому заказу'];
        }
        if (!OrderStatus::canClientCancel((string) $row['status'])) {
            return ['ok' => false, 'message' => 'Заказ уже нельзя отменить'];
        }
        $this->pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')
            ->execute([OrderStatus::CANCELLED, $orderId]);

        return ['ok' => true, 'message' => 'Заказ отменён'];
    }

    /** @return list<array<string,mixed>> */
    public function listForUser(int $userId): array
    {
        if ($userId < 1) {
            return [];
        }
        OrderProgress::syncActiveOrders($this->pdo);
        $st = $this->pdo->prepare('SELECT id FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 50');
        $st->execute([$userId]);
        $out = [];
        foreach ($st->fetchAll() as $row) {
            $p = $this->getOrderPayload((int) $row['id']);
            if ($p) {
                $out[] = $p;
            }
        }

        return $out;
    }

    /** @return array<string,mixed>|null */
    public function findActiveOrderForUser(int $userId): ?array
    {
        if ($userId < 1) {
            return null;
        }
        OrderProgress::syncActiveOrders($this->pdo);
        $st = $this->pdo->prepare(
            "SELECT id FROM orders
             WHERE user_id = ? AND status IN ('accepted', 'preparing', 'delivering')
             ORDER BY id DESC LIMIT 1"
        );
        $st->execute([$userId]);
        $row = $st->fetch();
        if (!$row) {
            return null;
        }

        return $this->getOrderPayload((int) $row['id']);
    }

    private static function sessionUserId(\PDO $pdo): int
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        $uid = (int) ($_SESSION['auth_user_id'] ?? 0);
        if ($uid < 1) {
            return 0;
        }
        $st = $pdo->prepare('SELECT id FROM users WHERE id = ?');
        $st->execute([$uid]);

        return $st->fetch() ? $uid : 0;
    }

    public static function normalizePhoneRu(string $raw): string
    {
        $digits = preg_replace('/\D+/', '', $raw);
        if ($digits === '') {
            return '';
        }
        if (str_starts_with($digits, '8') && strlen($digits) === 11) {
            $digits = '7' . substr($digits, 1);
        }
        if (strlen($digits) === 10 && $digits[0] === '9') {
            $digits = '7' . $digits;
        }
        if (strlen($digits) === 11 && $digits[0] === '7') {
            return '+' . $digits;
        }

        return '';
    }

    private function getOrderPayload(int $orderId): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT o.id, o.user_id, o.customer_name, o.phone, o.address, o.address_lat, o.address_lng, o.comment, o.status, o.total_cents,
                    o.items_total_cents, o.delivery_fee_cents, o.delivery_zone_id, o.placed_at, o.created_at, dz.name AS delivery_zone_name
             FROM orders o
             LEFT JOIN delivery_zones dz ON dz.id = o.delivery_zone_id
             WHERE o.id = ?'
        );
        $st->execute([$orderId]);
        $o = $st->fetch();
        if (!$o) {
            return null;
        }
        $it = $this->pdo->prepare(
            'SELECT oi.dish_id, oi.quantity, oi.price_cents, d.name AS dish_name
             FROM order_items oi JOIN dishes d ON d.id = oi.dish_id WHERE oi.order_id = ?'
        );
        $it->execute([$orderId]);
        $items = [];
        foreach ($it->fetchAll() as $row) {
            $items[] = [
                'dish_id' => (int) $row['dish_id'],
                'dish_name' => $row['dish_name'],
                'quantity' => (int) $row['quantity'],
                'price_cents' => (int) $row['price_cents'],
                'line_total_cents' => (int) $row['price_cents'] * (int) $row['quantity'],
            ];
        }

        return [
            'id' => (int) $o['id'],
            'user_id' => isset($o['user_id']) && $o['user_id'] !== null && $o['user_id'] !== ''
                ? (int) $o['user_id']
                : null,
            'customer_name' => $o['customer_name'],
            'phone' => $o['phone'],
            'address' => $o['address'],
            'address_lat' => isset($o['address_lat']) && $o['address_lat'] !== null && $o['address_lat'] !== ''
                ? (float) $o['address_lat']
                : null,
            'address_lng' => isset($o['address_lng']) && $o['address_lng'] !== null && $o['address_lng'] !== ''
                ? (float) $o['address_lng']
                : null,
            'comment' => $o['comment'],
            'delivery_zone_id' => isset($o['delivery_zone_id']) ? (int) $o['delivery_zone_id'] : null,
            'delivery_zone_name' => $o['delivery_zone_name'] ?? null,
            'status' => OrderStatus::normalize((string) $o['status']),
            'status_label' => OrderStatus::labelRu((string) $o['status']),
            'is_active' => OrderStatus::isActiveDelivery((string) $o['status']),
            'delivery_timeline' => OrderProgress::timeline((string) $o['status']),
            'eta_minutes' => OrderProgress::etaMinutes((string) $o['status'], (int) ($o['placed_at'] ?? 0)),
            'placed_at' => (int) ($o['placed_at'] ?? 0),
            'items_total_cents' => (int) $o['items_total_cents'],
            'delivery_fee_cents' => (int) $o['delivery_fee_cents'],
            'total' => (int) $o['total_cents'] / 100,
            'total_cents' => (int) $o['total_cents'],
            'created_at' => $o['created_at'],
            'items' => $items,
        ];
    }

    /** @return array<string,mixed>|null */
    private function resolveDeliveryZone(int $zoneId): ?array
    {
        if ($zoneId > 0) {
            $st = $this->pdo->prepare('SELECT id, name, min_order_cents, delivery_fee_cents FROM delivery_zones WHERE id = ?');
            $st->execute([$zoneId]);
            $row = $st->fetch();

            return $row ?: null;
        }

        $row = $this->pdo->query(
            'SELECT id, name, min_order_cents, delivery_fee_cents FROM delivery_zones ORDER BY id LIMIT 1'
        )->fetch();

        return $row ?: null;
    }
}

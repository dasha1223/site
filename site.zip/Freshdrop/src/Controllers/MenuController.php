<?php

declare(strict_types=1);

final class MenuController
{
    public function __construct(private \PDO $pdo) {}

    public function list(): void
    {
        $cats = $this->pdo->query('SELECT id, name, sort_order FROM categories ORDER BY sort_order, id')
            ->fetchAll();
        foreach ($cats as &$c) {
            $st = $this->pdo->prepare(
                'SELECT id, category_id, name, description, composition, price_cents, image_url, is_available
                 FROM dishes WHERE category_id = ? ORDER BY id'
            );
            $st->execute([(int) $c['id']]);
            $c['dishes'] = array_map([$this, 'formatDish'], $st->fetchAll());
        }
        unset($c);
        Response::success(['categories' => $cats]);
    }

    public function one(string $id): void
    {
        $st = $this->pdo->prepare(
            'SELECT d.id, d.category_id, d.name, d.description, d.composition, d.price_cents, d.image_url, d.is_available,
                    c.name AS category_name
             FROM dishes d JOIN categories c ON c.id = d.category_id WHERE d.id = ?'
        );
        $st->execute([(int) $id]);
        $row = $st->fetch();
        if (!$row) {
            Response::error('NOT_FOUND', 'Блюдо не найдено', 404);
            return;
        }
        Response::success($this->formatDish($row));
    }

    private function formatDish(array $row): array
    {
        $gallery = $this->galleryForDish((int) $row['id']);

        return [
            'id' => (int) $row['id'],
            'category_id' => (int) $row['category_id'],
            'name' => $row['name'],
            'description' => $row['description'],
            'composition' => $row['composition'] ?? null,
            'price' => (int) $row['price_cents'] / 100,
            'price_cents' => (int) $row['price_cents'],
            'image_url' => $this->assetUrl((string) $row['image_url']),
            'images' => $gallery,
            'is_available' => (bool) (int) $row['is_available'],
            'category_name' => $row['category_name'] ?? null,
        ];
    }

    /** @return list<string> */
    private function galleryForDish(int $dishId): array
    {
        $st = $this->pdo->prepare('SELECT image_url FROM dish_images WHERE dish_id = ? ORDER BY sort_order, id');
        $st->execute([$dishId]);
        $images = [];
        foreach ($st->fetchAll() as $row) {
            $url = $this->assetUrl((string) ($row['image_url'] ?? ''));
            if ($url !== '') {
                $images[] = $url;
            }
        }

        return $images;
    }

    private function assetUrl(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $raw)) {
            return $raw;
        }
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

        return ($base === '' ? '' : $base . '/') . ltrim($raw, '/');
    }
}

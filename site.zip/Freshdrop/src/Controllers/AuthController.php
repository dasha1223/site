<?php

declare(strict_types=1);

final class AuthController
{
    public function __construct(
        private \PDO $pdo,
        private array $config,
    ) {}

    public static function currentUser(\PDO $pdo): ?array
    {
        self::ensureSession();
        $uid = (int) ($_SESSION['auth_user_id'] ?? 0);
        if ($uid < 1) {
            return null;
        }

        $st = $pdo->prepare(
            'SELECT id, display_name, avatar_url, email, saved_delivery_name, saved_delivery_phone, saved_delivery_address, saved_delivery_comment, created_at, last_login_at FROM users WHERE id = ?'
        );
        $st->execute([$uid]);
        $u = $st->fetch();
        if (!$u) {
            unset($_SESSION['auth_user_id']);
            return null;
        }

        $acc = $pdo->prepare('SELECT provider, email, username, profile_url FROM social_accounts WHERE user_id = ? ORDER BY id');
        $acc->execute([$uid]);
        $u['accounts'] = $acc->fetchAll();
        $u['id'] = (int) $u['id'];
        return $u;
    }

    public function loginPage(): void
    {
        $user = self::currentUser($this->pdo);
        if ($user) {
            header('Location: ' . $this->url('/profile'), true, 302);
            exit;
        }

        header('Content-Type: text/html; charset=utf-8');
        $flashError = $this->popFlash('auth_error');
        $tgBotUsername = ltrim((string) ($this->config['oauth']['telegram']['bot_username'] ?? ''), '@');
        $vkEnabled = $this->isProviderEnabled('vk');
        $yandexEnabled = $this->isProviderEnabled('yandex');
        require PROJECT_ROOT . '/views/auth_login.php';
    }

    public function emailLogin(): void
    {
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        if ($email === '' || $password === '') {
            $this->setFlash('auth_error', 'Введите почту и пароль.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }

        $st = $this->pdo->prepare('SELECT id, password_hash FROM users WHERE lower(trim(email)) = ?');
        $st->execute([$email]);
        $row = $st->fetch();
        if (!$row) {
            $this->setFlash('auth_error', 'Аккаунта с такой почтой нет. Сначала зарегистрируйтесь.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }

        $hash = (string) ($row['password_hash'] ?? '');
        if ($hash === '') {
            $this->setFlash('auth_error', 'У этого аккаунта нет пароля — войдите через соцсеть или зарегистрируйтесь по почте.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        if (!password_verify($password, $hash)) {
            $this->setFlash('auth_error', 'Неверный пароль.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }

        self::ensureSession();
        $uid = (int) $row['id'];
        $this->pdo->prepare('UPDATE users SET last_login_at = datetime("now") WHERE id = ?')->execute([$uid]);
        $_SESSION['auth_user_id'] = $uid;
        header('Location: ' . $this->url('/profile'), true, 302);
        exit;
    }

    public function register(): void
    {
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $name = trim((string) ($_POST['display_name'] ?? ''));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->setFlash('auth_error', 'Укажите корректную почту.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        if (strlen($password) < 6) {
            $this->setFlash('auth_error', 'Пароль не короче 6 символов.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        if ($name === '') {
            $name = (string) (preg_replace('/@.*$/', '', $email) ?: 'Пользователь');
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $ins = $this->pdo->prepare(
                'INSERT INTO users (display_name, avatar_url, email, password_hash, created_at, last_login_at)
                 VALUES (?, NULL, ?, ?, datetime("now"), datetime("now"))'
            );
            $ins->execute([$name, $email, $hash]);
        } catch (\PDOException) {
            $this->setFlash('auth_error', 'Эта почта уже зарегистрирована.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }

        self::ensureSession();
        $_SESSION['auth_user_id'] = (int) $this->pdo->lastInsertId();
        header('Location: ' . $this->url('/profile'), true, 302);
        exit;
    }

    public function profilePage(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            $this->setFlash('auth_error', 'Войдите, чтобы открыть профиль.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        header('Content-Type: text/html; charset=utf-8');
        $orderCtrl = new OrderController($this->pdo);
        $activeOrder = $orderCtrl->findActiveOrderForUser((int) $user['id']);
        $orderHistory = $orderCtrl->listForUser((int) $user['id']);
        if ($activeOrder !== null) {
            $activeId = (int) ($activeOrder['id'] ?? 0);
            $orderHistory = array_values(array_filter(
                $orderHistory,
                static fn (array $o): bool => (int) ($o['id'] ?? 0) !== $activeId
            ));
        }
        $profileFlashOk = $this->popFlash('profile_ok');
        $profileFlashErr = $this->popFlash('profile_error');
        $tgBotUsername = ltrim((string) ($this->config['oauth']['telegram']['bot_username'] ?? ''), '@');
        $vkEnabled = $this->isProviderEnabled('vk');
        $yandexEnabled = $this->isProviderEnabled('yandex');
        $hp = $this->pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $hp->execute([(int) $user['id']]);
        $hasPassword = (string) ($hp->fetchColumn() ?: '') !== '';
        require PROJECT_ROOT . '/views/profile.php';
    }

    public function cancelOrder(int $orderId): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            $this->setFlash('auth_error', 'Войдите в личный кабинет.');
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        $result = (new OrderController($this->pdo))->cancelByUser($orderId, (int) $user['id']);
        if ($result['ok']) {
            $this->setFlash('profile_ok', $result['message']);
        } else {
            $this->setFlash('profile_error', $result['message']);
        }
        header('Location: ' . $this->url('/profile') . '#orders', true, 302);
        exit;
    }

    public function saveProfileSettings(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        $name = trim((string) ($_POST['display_name'] ?? ''));
        $avatarUrl = trim((string) ($_POST['avatar_url'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $dn = trim((string) ($_POST['saved_delivery_name'] ?? ''));
        $dp = OrderController::normalizePhoneRu((string) ($_POST['saved_delivery_phone'] ?? ''));
        $da = trim((string) ($_POST['saved_delivery_address'] ?? ''));
        $dc = trim((string) ($_POST['saved_delivery_comment'] ?? ''));

        if ($name === '') {
            $this->setFlash('profile_error', 'Укажите имя.');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->setFlash('profile_error', 'Некорректная почта.');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        if ($dp !== '' && !preg_match('/^\+7\d{10}$/', $dp)) {
            $this->setFlash('profile_error', 'Телефон для доставки: +7 и 10 цифр.');
            header('Location: ' . $this->url('/profile') . '#delivery', true, 302);
            exit;
        }

        $uid = (int) $user['id'];
        $avatarDb = $avatarUrl !== '' ? $avatarUrl : null;

        if ($email !== '') {
            $chk = $this->pdo->prepare('SELECT id FROM users WHERE lower(trim(email)) = ? AND id != ?');
            $chk->execute([$email, $uid]);
            if ($chk->fetch()) {
                $this->setFlash('profile_error', 'Эта почта уже занята другим аккаунтом.');
                header('Location: ' . $this->url('/profile') . '#settings', true, 302);
                exit;
            }
        }

        $this->pdo->prepare(
            'UPDATE users SET display_name = ?, avatar_url = ?,
             email = CASE WHEN ? != \'\' THEN ? ELSE email END,
             saved_delivery_name = NULLIF(?, \'\'), saved_delivery_phone = NULLIF(?, \'\'),
             saved_delivery_address = NULLIF(?, \'\'), saved_delivery_comment = NULLIF(?, \'\')
             WHERE id = ?'
        )->execute([
            $name,
            $avatarDb,
            $email,
            $email,
            $dn !== '' ? $dn : null,
            $dp !== '' ? $dp : null,
            $da !== '' ? $da : null,
            $dc !== '' ? $dc : null,
            $uid,
        ]);

        $this->setFlash('profile_ok', 'Профиль сохранён.');
        header('Location: ' . $this->url('/profile') . '#settings', true, 302);
        exit;
    }

    public function changePassword(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        $st = $this->pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([(int) $user['id']]);
        $hash = (string) ($st->fetchColumn() ?: '');
        if ($hash === '') {
            $this->setFlash('profile_error', 'Пароль не задан — войдите через соцсеть или задайте пароль при регистрации.');
            header('Location: ' . $this->url('/profile') . '#security', true, 302);
            exit;
        }
        $old = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        if (!password_verify($old, $hash)) {
            $this->setFlash('profile_error', 'Текущий пароль указан неверно.');
            header('Location: ' . $this->url('/profile') . '#security', true, 302);
            exit;
        }
        if (strlen($new) < 6) {
            $this->setFlash('profile_error', 'Новый пароль не короче 6 символов.');
            header('Location: ' . $this->url('/profile') . '#security', true, 302);
            exit;
        }
        $this->pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([
            password_hash($new, PASSWORD_DEFAULT),
            (int) $user['id'],
        ]);
        $this->setFlash('profile_ok', 'Пароль обновлён.');
        header('Location: ' . $this->url('/profile') . '#security', true, 302);
        exit;
    }

    public function setInitialPassword(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        $st = $this->pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([(int) $user['id']]);
        if ((string) ($st->fetchColumn() ?: '') !== '') {
            $this->setFlash('profile_error', 'Пароль уже задан — используйте смену пароля.');
            header('Location: ' . $this->url('/profile') . '#security', true, 302);
            exit;
        }
        $new = (string) ($_POST['new_password'] ?? '');
        if (strlen($new) < 6) {
            $this->setFlash('profile_error', 'Пароль не короче 6 символов.');
            header('Location: ' . $this->url('/profile') . '#security', true, 302);
            exit;
        }
        $this->pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([
            password_hash($new, PASSWORD_DEFAULT),
            (int) $user['id'],
        ]);
        $this->setFlash('profile_ok', 'Пароль для входа по почте установлен.');
        header('Location: ' . $this->url('/profile') . '#security', true, 302);
        exit;
    }

    public function uploadAvatar(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        if (!isset($_FILES['avatar']) || !is_array($_FILES['avatar']) || ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $this->setFlash('profile_error', 'Выберите файл изображения.');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        $tmp = (string) $_FILES['avatar']['tmp_name'];
        $size = (int) ($_FILES['avatar']['size'] ?? 0);
        if ($size < 1 || $size > 2_500_000) {
            $this->setFlash('profile_error', 'Файл слишком большой (максимум ~2,5 МБ).');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmp) ?: '';
        $extMap = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
        ];
        $ext = $extMap[$mime] ?? '';
        if ($ext === '') {
            $this->setFlash('profile_error', 'Допустимы JPG, PNG, WebP или GIF.');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        $uid = (int) $user['id'];
        foreach (glob(PROJECT_ROOT . '/storage/avatars/' . $uid . '.*') ?: [] as $old) {
            @unlink($old);
        }
        $dest = PROJECT_ROOT . '/storage/avatars/' . $uid . '.' . $ext;
        if (!move_uploaded_file($tmp, $dest)) {
            $this->setFlash('profile_error', 'Не удалось сохранить файл.');
            header('Location: ' . $this->url('/profile') . '#settings', true, 302);
            exit;
        }
        $publicUrl = $this->url('/user-media/avatar/' . $uid . '.' . $ext);
        $this->pdo->prepare('UPDATE users SET avatar_url = ? WHERE id = ?')->execute([$publicUrl, $uid]);
        $this->setFlash('profile_ok', 'Аватар обновлён.');
        header('Location: ' . $this->url('/profile') . '#settings', true, 302);
        exit;
    }

    public function unlinkSocial(): void
    {
        $user = self::currentUser($this->pdo);
        if (!$user) {
            header('Location: ' . $this->url('/auth/login'), true, 302);
            exit;
        }
        $provider = trim((string) ($_POST['provider'] ?? ''));
        if (!in_array($provider, ['telegram', 'vk', 'yandex'], true)) {
            $this->setFlash('profile_error', 'Неизвестный провайдер.');
            header('Location: ' . $this->url('/profile') . '#linked', true, 302);
            exit;
        }
        $uid = (int) $user['id'];
        $st = $this->pdo->prepare('SELECT COUNT(*) FROM social_accounts WHERE user_id = ?');
        $st->execute([$uid]);
        $nSocial = (int) $st->fetchColumn();
        $st = $this->pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([$uid]);
        $hasPwd = (string) ($st->fetchColumn() ?: '') !== '';
        if ($nSocial <= 1 && !$hasPwd) {
            $this->setFlash('profile_error', 'Нельзя отвязать единственный способ входа. Добавьте пароль или другую соцсеть.');
            header('Location: ' . $this->url('/profile') . '#linked', true, 302);
            exit;
        }
        $chk = $this->pdo->prepare('SELECT 1 FROM social_accounts WHERE user_id = ? AND provider = ?');
        $chk->execute([$uid, $provider]);
        if (!$chk->fetch()) {
            $this->setFlash('profile_error', 'Эта сеть не была привязана.');
        } else {
            $this->pdo->prepare('DELETE FROM social_accounts WHERE user_id = ? AND provider = ?')->execute([$uid, $provider]);
            $this->setFlash('profile_ok', 'Связь с аккаунтом отключена.');
        }
        header('Location: ' . $this->url('/profile') . '#linked', true, 302);
        exit;
    }

    /** Отдача загруженного аватара (статический путь без сессии). */
    public static function serveAvatarIfExists(string $path): bool
    {
        if (!preg_match('#^/user-media/avatar/(\d+)\.(jpe?g|png|gif|webp)$#i', $path, $m)) {
            return false;
        }
        $uid = (int) $m[1];
        $ext = strtolower($m[2]);
        if ($ext === 'jpeg') {
            $ext = 'jpg';
        }
        $file = PROJECT_ROOT . '/storage/avatars/' . $uid . '.' . $ext;
        if (!is_file($file)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Not found';
            return true;
        }
        $types = [
            'jpg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
        ];
        header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
        header('Cache-Control: public, max-age=86400');
        readfile($file);

        return true;
    }

    public function logout(): void
    {
        self::ensureSession();
        unset($_SESSION['auth_user_id']);
        header('Location: ' . $this->url('/'), true, 302);
        exit;
    }

    public function redirectVk(): void
    {
        if (!$this->isProviderEnabled('vk')) {
            $this->oauthError('VK пока не настроен.');
        }
        $state = $this->issueState('vk');
        $url = 'https://oauth.vk.com/authorize?' . http_build_query([
            'client_id' => $this->config['oauth']['vk']['client_id'],
            'redirect_uri' => $this->redirectUri('/auth/vk/callback'),
            'response_type' => 'code',
            'scope' => 'email',
            'state' => $state,
            'v' => '5.199',
        ]);
        header('Location: ' . $url, true, 302);
        exit;
    }

    public function callbackVk(): void
    {
        if (!$this->verifyState('vk', (string) ($_GET['state'] ?? ''))) {
            $this->oauthError('Ошибка состояния сессии VK.');
        }
        $code = (string) ($_GET['code'] ?? '');
        if ($code === '') {
            $this->oauthError('VK не вернул код авторизации.');
        }

        $token = $this->httpGetJson('https://oauth.vk.com/access_token?' . http_build_query([
            'client_id' => $this->config['oauth']['vk']['client_id'],
            'client_secret' => $this->config['oauth']['vk']['client_secret'],
            'redirect_uri' => $this->redirectUri('/auth/vk/callback'),
            'code' => $code,
        ]));

        $accessToken = (string) ($token['access_token'] ?? '');
        $providerUserId = (string) ($token['user_id'] ?? '');
        if ($accessToken === '' || $providerUserId === '') {
            $this->oauthError('Не удалось получить токен VK.');
        }

        $profileResp = $this->httpGetJson('https://api.vk.com/method/users.get?' . http_build_query([
            'access_token' => $accessToken,
            'user_ids' => $providerUserId,
            'fields' => 'photo_200,screen_name',
            'v' => '5.199',
        ]));

        $u = $profileResp['response'][0] ?? null;
        if (!is_array($u)) {
            $this->oauthError('Не удалось получить профиль VK.');
        }

        $name = trim(((string) ($u['first_name'] ?? '')) . ' ' . ((string) ($u['last_name'] ?? '')));
        if ($name === '') {
            $name = 'Пользователь VK';
        }

        $this->loginOrLink(
            'vk',
            $providerUserId,
            $name,
            (string) ($u['photo_200'] ?? ''),
            (string) ($token['email'] ?? ''),
            (string) ($u['screen_name'] ?? ''),
            isset($u['screen_name']) ? ('https://vk.com/' . (string) $u['screen_name']) : '',
            $u
        );
    }

    public function redirectYandex(): void
    {
        if (!$this->isProviderEnabled('yandex')) {
            $this->oauthError('Yandex ID пока не настроен.');
        }
        $state = $this->issueState('yandex');
        $url = 'https://oauth.yandex.ru/authorize?' . http_build_query([
            'response_type' => 'code',
            'client_id' => $this->config['oauth']['yandex']['client_id'],
            'state' => $state,
        ]);
        header('Location: ' . $url, true, 302);
        exit;
    }

    public function callbackYandex(): void
    {
        if (!$this->verifyState('yandex', (string) ($_GET['state'] ?? ''))) {
            $this->oauthError('Ошибка состояния сессии Yandex.');
        }
        $code = (string) ($_GET['code'] ?? '');
        if ($code === '') {
            $this->oauthError('Yandex не вернул код авторизации.');
        }

        $token = $this->httpPostForm('https://oauth.yandex.ru/token', [
            'grant_type' => 'authorization_code',
            'code' => $code,
            'client_id' => $this->config['oauth']['yandex']['client_id'],
            'client_secret' => $this->config['oauth']['yandex']['client_secret'],
        ]);
        $accessToken = (string) ($token['access_token'] ?? '');
        if ($accessToken === '') {
            $this->oauthError('Не удалось получить токен Yandex.');
        }

        $profile = $this->httpGetJson(
            'https://login.yandex.ru/info?format=json',
            ['Authorization: OAuth ' . $accessToken]
        );

        $providerUserId = (string) ($profile['id'] ?? '');
        if ($providerUserId === '') {
            $this->oauthError('Не удалось получить профиль Yandex.');
        }

        $name = (string) ($profile['real_name'] ?? $profile['display_name'] ?? $profile['login'] ?? 'Пользователь Yandex');

        $this->loginOrLink(
            'yandex',
            $providerUserId,
            $name,
            (string) ($profile['default_avatar_id'] ?? '') !== ''
                ? ('https://avatars.yandex.net/get-yapic/' . $profile['default_avatar_id'] . '/islands-200')
                : '',
            (string) ($profile['default_email'] ?? ''),
            (string) ($profile['login'] ?? ''),
            '',
            $profile
        );
    }

    public function telegramLogin(): void
    {
        $payload = file_get_contents('php://input') ?: '';
        try {
            $data = json_decode($payload, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            Response::error('BAD_JSON', 'Некорректный JSON', 400);
            return;
        }

        $botToken = (string) ($this->config['oauth']['telegram']['bot_token'] ?? '');
        if ($botToken === '') {
            Response::error('NOT_CONFIGURED', 'Telegram не настроен', 400);
            return;
        }

        if (!$this->verifyTelegramData($data, $botToken)) {
            Response::error('INVALID_TELEGRAM', 'Не удалось проверить данные Telegram', 401);
            return;
        }

        $providerUserId = (string) ($data['id'] ?? '');
        if ($providerUserId === '') {
            Response::error('INVALID_TELEGRAM', 'Нет id Telegram', 400);
            return;
        }

        $name = trim(((string) ($data['first_name'] ?? '')) . ' ' . ((string) ($data['last_name'] ?? '')));
        if ($name === '') {
            $name = (string) ($data['username'] ?? 'Пользователь Telegram');
        }

        $this->loginOrLink(
            'telegram',
            $providerUserId,
            $name,
            (string) ($data['photo_url'] ?? ''),
            '',
            (string) ($data['username'] ?? ''),
            isset($data['username']) ? ('https://t.me/' . (string) $data['username']) : '',
            $data,
            true
        );
    }

    private function loginOrLink(
        string $provider,
        string $providerUserId,
        string $displayName,
        string $avatarUrl,
        string $email,
        string $username,
        string $profileUrl,
        array $raw,
        bool $jsonResponse = false,
    ): void {
        self::ensureSession();
        $sessionUid = (int) ($_SESSION['auth_user_id'] ?? 0);

        $st = $this->pdo->prepare('SELECT user_id FROM social_accounts WHERE provider = ? AND provider_user_id = ?');
        $st->execute([$provider, $providerUserId]);
        $boundUserId = (int) ($st->fetchColumn() ?: 0);

        if ($sessionUid > 0) {
            if ($boundUserId > 0 && $boundUserId !== $sessionUid) {
                $this->socialLinkFailure($jsonResponse, 'Этот аккаунт уже привязан к другому профилю.');
            }
            if ($boundUserId === $sessionUid) {
                $this->updateSocialAccountRow($provider, $providerUserId, $email, $username, $profileUrl, $raw);
            } else {
                $this->insertSocialAccountRow(
                    $sessionUid,
                    $provider,
                    $providerUserId,
                    $email,
                    $username,
                    $profileUrl,
                    $raw
                );
            }
            if ($email !== '') {
                $this->maybeFillUserEmail($sessionUid, $email);
            }
            $this->setFlash('profile_ok', 'Аккаунт привязан.');
            $this->finishSocialRedirect($jsonResponse);
        }

        $userId = $boundUserId;
        if ($userId < 1) {
            $insUser = $this->pdo->prepare(
                'INSERT INTO users (display_name, avatar_url, created_at, last_login_at) VALUES (?, ?, datetime("now"), datetime("now"))'
            );
            $insUser->execute([$displayName, $avatarUrl !== '' ? $avatarUrl : null]);
            $userId = (int) $this->pdo->lastInsertId();

            $this->insertSocialAccountRow(
                $userId,
                $provider,
                $providerUserId,
                $email,
                $username,
                $profileUrl,
                $raw
            );
        } else {
            $updUser = $this->pdo->prepare(
                'UPDATE users SET display_name = ?, avatar_url = ?, last_login_at = datetime("now") WHERE id = ?'
            );
            $updUser->execute([$displayName, $avatarUrl !== '' ? $avatarUrl : null, $userId]);

            $this->updateSocialAccountRow($provider, $providerUserId, $email, $username, $profileUrl, $raw);
        }

        $_SESSION['auth_user_id'] = $userId;
        $this->finishSocialRedirect($jsonResponse);
    }

    /** @return never */
    private function socialLinkFailure(bool $jsonResponse, string $message): void
    {
        if ($jsonResponse) {
            Response::error('LINK_CONFLICT', $message, 409);
        } else {
            $this->setFlash('profile_error', $message);
            header('Location: ' . $this->url('/profile') . '#linked', true, 302);
        }
        exit;
    }

    /** @return never */
    private function finishSocialRedirect(bool $jsonResponse): void
    {
        if ($jsonResponse) {
            Response::success(['redirect' => $this->url('/profile')]);
        } else {
            header('Location: ' . $this->url('/profile'), true, 302);
        }
        exit;
    }

    private function insertSocialAccountRow(
        int $userId,
        string $provider,
        string $providerUserId,
        string $email,
        string $username,
        string $profileUrl,
        array $raw,
    ): void {
        $insAccount = $this->pdo->prepare(
            'INSERT INTO social_accounts
                (user_id, provider, provider_user_id, email, username, profile_url, raw_json, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, datetime("now"), datetime("now"))'
        );
        $insAccount->execute([
            $userId,
            $provider,
            $providerUserId,
            $email !== '' ? $email : null,
            $username !== '' ? $username : null,
            $profileUrl !== '' ? $profileUrl : null,
            json_encode($raw, JSON_UNESCAPED_UNICODE),
        ]);
    }

    private function updateSocialAccountRow(
        string $provider,
        string $providerUserId,
        string $email,
        string $username,
        string $profileUrl,
        array $raw,
    ): void {
        $updAccount = $this->pdo->prepare(
            'UPDATE social_accounts
             SET email = ?, username = ?, profile_url = ?, raw_json = ?, updated_at = datetime("now")
             WHERE provider = ? AND provider_user_id = ?'
        );
        $updAccount->execute([
            $email !== '' ? $email : null,
            $username !== '' ? $username : null,
            $profileUrl !== '' ? $profileUrl : null,
            json_encode($raw, JSON_UNESCAPED_UNICODE),
            $provider,
            $providerUserId,
        ]);
    }

    private function maybeFillUserEmail(int $userId, string $email): void
    {
        $e = strtolower(trim($email));
        $chk = $this->pdo->prepare('SELECT id FROM users WHERE lower(trim(email)) = ? AND id != ?');
        $chk->execute([$e, $userId]);
        if ($chk->fetch()) {
            return;
        }
        $this->pdo->prepare(
            'UPDATE users SET email = ? WHERE id = ? AND (email IS NULL OR trim(email) = \'\')'
        )->execute([$e, $userId]);
    }

    private function oauthError(string $message): never
    {
        self::ensureSession();
        if ((int) ($_SESSION['auth_user_id'] ?? 0) > 0) {
            $this->setFlash('profile_error', $message);
            header('Location: ' . $this->url('/profile') . '#linked', true, 302);
            exit;
        }
        $this->failAuth($message);
    }

    private function isProviderEnabled(string $provider): bool
    {
        $cfg = $this->config['oauth'][$provider] ?? null;
        if (!is_array($cfg)) {
            return false;
        }
        return ((string) ($cfg['client_id'] ?? '')) !== '' && ((string) ($cfg['client_secret'] ?? '')) !== '';
    }

    private function issueState(string $provider): string
    {
        self::ensureSession();
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state_' . $provider] = $state;
        return $state;
    }

    private function verifyState(string $provider, string $state): bool
    {
        self::ensureSession();
        $key = 'oauth_state_' . $provider;
        $saved = (string) ($_SESSION[$key] ?? '');
        unset($_SESSION[$key]);
        return $saved !== '' && hash_equals($saved, $state);
    }

    private function failAuth(string $message): never
    {
        $this->setFlash('auth_error', $message);
        header('Location: ' . $this->url('/auth/login'), true, 302);
        exit;
    }

    private function url(string $path): string
    {
        $publicBase = trim((string) ($this->config['public_base_url'] ?? ''));
        if ($publicBase !== '') {
            return rtrim($publicBase, '/') . '/' . ltrim($path, '/');
        }
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        $suffix = '/' . ltrim($path, '/');
        return $base === '' ? $suffix : $base . $suffix;
    }

    private function redirectUri(string $path): string
    {
        $publicBase = trim((string) ($this->config['public_base_url'] ?? ''));
        if ($publicBase !== '') {
            return rtrim($publicBase, '/') . '/' . ltrim($path, '/');
        }
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        return $scheme . '://' . $host . $this->url($path);
    }

    private static function ensureSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    private function setFlash(string $key, string $value): void
    {
        self::ensureSession();
        $_SESSION['flash_' . $key] = $value;
    }

    private function popFlash(string $key): ?string
    {
        self::ensureSession();
        $k = 'flash_' . $key;
        $v = $_SESSION[$k] ?? null;
        unset($_SESSION[$k]);
        return is_string($v) ? $v : null;
    }

    /** @return array<string,mixed> */
    private function httpGetJson(string $url, array $headers = []): array
    {
        $raw = $this->httpRequest('GET', $url, '', $headers);
        $json = json_decode($raw, true);
        return is_array($json) ? $json : [];
    }

    /** @return array<string,mixed> */
    private function httpPostForm(string $url, array $data): array
    {
        $raw = $this->httpRequest(
            'POST',
            $url,
            http_build_query($data),
            ['Content-Type: application/x-www-form-urlencoded']
        );
        $json = json_decode($raw, true);
        return is_array($json) ? $json : [];
    }

    private function httpRequest(string $method, string $url, string $body = '', array $headers = []): string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($body !== '') {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
            if ($headers !== []) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            }
            $res = curl_exec($ch);
            curl_close($ch);
            return is_string($res) ? $res : '';
        }

        $context = stream_context_create([
            'http' => [
                'method' => $method,
                'header' => implode("\r\n", $headers),
                'content' => $body,
                'timeout' => 20,
                'ignore_errors' => true,
            ],
        ]);
        $raw = @file_get_contents($url, false, $context);
        return is_string($raw) ? $raw : '';
    }

    private function verifyTelegramData(array $data, string $botToken): bool
    {
        $hash = (string) ($data['hash'] ?? '');
        $authDate = (int) ($data['auth_date'] ?? 0);
        if ($hash === '' || $authDate < (time() - 86400)) {
            return false;
        }

        unset($data['hash']);
        ksort($data);
        $check = [];
        foreach ($data as $k => $v) {
            $check[] = $k . '=' . $v;
        }
        $checkString = implode("\n", $check);

        $secret = hash('sha256', $botToken, true);
        $calc = hash_hmac('sha256', $checkString, $secret);
        return hash_equals($calc, $hash);
    }
}
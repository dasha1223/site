<?php

declare(strict_types=1);

final class SchemaInstaller
{
    private const CATALOG_VERSION = '3';

    public static function ensure(\PDO $pdo): void
    {
        $schema = file_get_contents(PROJECT_ROOT . '/sql/schema.sql');
        $pdo->exec($schema);

        self::migrateUsersEmailPassword($pdo);
        self::migrateOrdersUserDeliveryPrefs($pdo);
        self::migrateDishComposition($pdo);
        self::migrateDishImages($pdo);
        self::migrateOrderStatuses($pdo);
        self::migrateOrderDeliveryFields($pdo);
        self::migrateOrderAddressCoords($pdo);
        self::migrateOrderPlacedAt($pdo);
        self::migrateApiTokens($pdo);
        self::ensureDemoApiUser($pdo);

        self::patchDishImageUrls($pdo);
        self::ensureDishGalleryFromMainImage($pdo);

        $stmt = $pdo->query("SELECT v FROM app_meta WHERE k = 'catalog_version'");
        $current = $stmt ? $stmt->fetchColumn() : false;

        if ($current === self::CATALOG_VERSION) {
            return;
        }

        if ($current !== false && $current !== null) {
            self::wipeCatalogAndOrders($pdo);
        } else {
            $hasData = (int) $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() > 0;
            if ($hasData) {
                self::wipeCatalogAndOrders($pdo);
            }
        }

        $pdo->exec(file_get_contents(PROJECT_ROOT . '/sql/seed.sql'));
        self::patchDishImageUrls($pdo);
        self::ensureDishGalleryFromMainImage($pdo);
        $pdo->exec(
            "INSERT OR REPLACE INTO app_meta (k, v) VALUES ('catalog_version', " . $pdo->quote(self::CATALOG_VERSION) . ')'
        );
    }

    private static function migrateUsersEmailPassword(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(users)')->fetchAll();
        $names = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('email', $names, true)) {
            $pdo->exec('ALTER TABLE users ADD COLUMN email TEXT');
        }
        if (!in_array('password_hash', $names, true)) {
            $pdo->exec('ALTER TABLE users ADD COLUMN password_hash TEXT');
        }
        $pdo->exec(
            'CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL AND trim(email) != \'\''
        );
    }

    private static function migrateOrdersUserDeliveryPrefs(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(orders)')->fetchAll();
        $orderNames = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('user_id', $orderNames, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN user_id INTEGER REFERENCES users(id) ON DELETE SET NULL');
        }
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id)');

        $uCols = $pdo->query('PRAGMA table_info(users)')->fetchAll();
        $userNames = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $uCols);
        foreach (
            [
                'saved_delivery_name' => 'TEXT',
                'saved_delivery_phone' => 'TEXT',
                'saved_delivery_address' => 'TEXT',
                'saved_delivery_comment' => 'TEXT',
            ] as $col => $type
        ) {
            if (!in_array($col, $userNames, true)) {
                $pdo->exec("ALTER TABLE users ADD COLUMN {$col} {$type}");
            }
        }
    }

    private static function migrateDishComposition(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(dishes)')->fetchAll();
        $names = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('composition', $names, true)) {
            $pdo->exec('ALTER TABLE dishes ADD COLUMN composition TEXT');
        }
        $pdo->exec(
            "UPDATE dishes SET composition = description
             WHERE composition IS NULL OR trim(composition) = ''"
        );
    }

    private static function migrateOrderStatuses(\PDO $pdo): void
    {
        $map = [
            'new' => 'accepted',
            'cooking' => 'preparing',
            'delivering' => 'delivering',
            'done' => 'received',
            'completed' => 'received',
        ];
        foreach ($map as $from => $to) {
            $st = $pdo->prepare('UPDATE orders SET status = ? WHERE status = ?');
            $st->execute([$to, $from]);
        }
    }

    private static function migrateDishImages(\PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS dish_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dish_id INTEGER NOT NULL REFERENCES dishes(id) ON DELETE CASCADE,
                image_url TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 0
            )'
        );
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_dish_images_dish ON dish_images(dish_id)');
    }

    private static function migrateOrderDeliveryFields(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(orders)')->fetchAll();
        $names = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('delivery_zone_id', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN delivery_zone_id INTEGER REFERENCES delivery_zones(id) ON DELETE SET NULL');
        }
        if (!in_array('items_total_cents', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN items_total_cents INTEGER NOT NULL DEFAULT 0');
            $pdo->exec('UPDATE orders SET items_total_cents = total_cents WHERE items_total_cents = 0');
        }
        if (!in_array('delivery_fee_cents', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN delivery_fee_cents INTEGER NOT NULL DEFAULT 0');
        }
    }

    private static function migrateOrderAddressCoords(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(orders)')->fetchAll();
        $names = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('address_lat', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN address_lat REAL');
        }
        if (!in_array('address_lng', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN address_lng REAL');
        }
    }

    private static function migrateOrderPlacedAt(\PDO $pdo): void
    {
        $cols = $pdo->query('PRAGMA table_info(orders)')->fetchAll();
        $names = array_map(static fn ($c) => (string) ($c['name'] ?? ''), $cols);
        if (!in_array('placed_at', $names, true)) {
            $pdo->exec('ALTER TABLE orders ADD COLUMN placed_at INTEGER NOT NULL DEFAULT 0');
        }
        $pdo->exec(
            "UPDATE orders SET placed_at = CAST(strftime('%s', created_at) AS INTEGER)
             WHERE placed_at = 0 AND created_at IS NOT NULL AND trim(created_at) != ''"
        );
        $pdo->exec('UPDATE orders SET placed_at = ' . time() . ' WHERE placed_at = 0');
    }

    private static function migrateApiTokens(\PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS api_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                token_hash TEXT NOT NULL UNIQUE,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                role TEXT NOT NULL CHECK (role IN (\'client\', \'admin\')),
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime(\'now\'))
            )'
        );
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_api_tokens_hash ON api_tokens(token_hash)');
    }

    private static function ensureDemoApiUser(\PDO $pdo): void
    {
        $email = 'demo@freshdrop.local';
        $st = $pdo->prepare('SELECT id FROM users WHERE lower(trim(email)) = ?');
        $st->execute([$email]);
        if ($st->fetch()) {
            return;
        }
        $hash = password_hash('demo123', PASSWORD_DEFAULT);
        $ins = $pdo->prepare(
            'INSERT INTO users (display_name, email, password_hash, saved_delivery_name, saved_delivery_phone, saved_delivery_address)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $ins->execute(['Демо клиент', $email, $hash, 'Демо клиент', '+79990001122', 'ул. Примерная, 1']);
    }

    private static function wipeCatalogAndOrders(\PDO $pdo): void
    {
        $pdo->exec('DELETE FROM order_items');
        $pdo->exec('DELETE FROM orders');
        $pdo->exec('DELETE FROM dishes');
        $pdo->exec('DELETE FROM categories');
    }

    /** Исправление URL превью для позиций, у которых не открывались картинки с CDN. */
    private static function patchDishImageUrls(\PDO $pdo): void
    {
        $urls = [
            8 => 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?auto=format&fit=crop&w=720&q=80',
            12 => 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=720&q=80',
            15 => 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=720&q=80',
            26 => 'https://images.unsplash.com/photo-1631531515722-c47833e38f25?auto=format&fit=crop&w=720&q=80',
            28 => 'https://images.unsplash.com/photo-1497534446932-c925b458314e?auto=format&fit=crop&w=720&q=80',
            32 => 'https://images.unsplash.com/photo-1563439633017-3bf254e037c9?auto=format&fit=crop&w=720&q=80',
        ];
        $st = $pdo->prepare('UPDATE dishes SET image_url = ? WHERE id = ?');
        foreach ($urls as $id => $url) {
            $check = $pdo->prepare('SELECT image_url FROM dishes WHERE id = ?');
            $check->execute([$id]);
            $current = (string) ($check->fetchColumn() ?: '');
            if ($current !== '' && !str_starts_with($current, 'http')) {
                continue;
            }
            $st->execute([$url, $id]);
        }
    }

    private static function ensureDishGalleryFromMainImage(\PDO $pdo): void
    {
        $rows = $pdo->query('SELECT id, category_id, name, image_url FROM dishes ORDER BY id')->fetchAll();
        $clear = $pdo->prepare('DELETE FROM dish_images WHERE dish_id = ?');
        $ins = $pdo->prepare('INSERT INTO dish_images (dish_id, image_url, sort_order) VALUES (?, ?, ?)');
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $categoryId = (int) ($row['category_id'] ?? 0);
            $name = (string) ($row['name'] ?? '');
            $image = trim((string) ($row['image_url'] ?? ''));
            if ($image === '') {
                continue;
            }
            $clear->execute([$id]);
            $ins->execute([$id, $image, 1]);
            foreach (self::derivedGalleryImages($image, $categoryId, $name) as $idx => $extra) {
                $ins->execute([$id, $extra, $idx + 2]);
            }
        }
    }

    /** @return list<string> */
    private static function derivedGalleryImages(string $image, int $categoryId, string $dishName): array
    {
        if (!preg_match('#^https?://#i', $image)) {
            return [];
        }

        $pool = self::categoryImagePool($categoryId);
        if ($pool === []) {
            $pool = self::categoryImagePool(0);
        }

        $seed = abs(crc32($image . '|' . mb_strtolower($dishName, 'UTF-8')));
        $out = [];
        $cursor = $seed % max(1, count($pool));
        $guard = 0;
        while (count($out) < 2 && $guard < 20) {
            $candidate = $pool[$cursor % count($pool)];
            $cursor += 3;
            $guard++;
            if (self::isSamePhoto($candidate, $image)) {
                continue;
            }
            if (in_array($candidate, $out, true)) {
                continue;
            }
            $out[] = $candidate;
        }

        return $out;
    }

    private static function isSamePhoto(string $a, string $b): bool
    {
        if ($a === $b) {
            return true;
        }
        if (preg_match('#/photo-[^?]+#', $a, $ma) && preg_match('#/photo-[^?]+#', $b, $mb)) {
            return $ma[0] === $mb[0];
        }

        return false;
    }

    /** @return list<string> */
    private static function categoryImagePool(int $categoryId): array
    {
        return match ($categoryId) {
            // Пицца
            1 => [
                'https://images.unsplash.com/photo-1548365328-9f547fb0953c?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1598023696416-0193a0bcd302?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=900&q=80',
            ],
            // Суши/роллы
            2 => [
                'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1534256958597-7fe685cbd745?auto=format&fit=crop&w=900&q=80',
            ],
            // Бургеры
            3 => [
                'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1520072959219-c595dc870360?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=900&q=80',
            ],
            // Горячее/WOK
            4 => [
                'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1617093727343-374698b1b08d?auto=format&fit=crop&w=900&q=80',
            ],
            // Закуски
            5 => [
                'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1546793665-c74683f339c1?auto=format&fit=crop&w=900&q=80',
            ],
            // Десерты
            6 => [
                'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=900&q=80',
            ],
            // Напитки
            7 => [
                'https://images.unsplash.com/photo-1497534446932-c925b458314e?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1523677011781-c91d1bbe2f9e?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1563439633017-3bf254e037c9?auto=format&fit=crop&w=900&q=80',
            ],
            default => [
                'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=900&q=80',
                'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=80',
            ],
        };
    }
}

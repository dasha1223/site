<?php

declare(strict_types=1);

$config = require __DIR__ . '/src/bootstrap.php';
$pdo = Database::pdo($config['db_path']);
SchemaInstaller::ensure($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');
    exit;
}

$uri = $_SERVER['REQUEST_URI'] ?? '/';
$rawPath = parse_url($uri, PHP_URL_PATH) ?: '/';
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if ($base !== '' && str_starts_with($rawPath, $base)) {
    $path = substr($rawPath, strlen($base)) ?: '/';
} else {
    $path = $rawPath;
}
$path = rtrim($path, '/') ?: '/';
if ($path === '/index.php') {
    $path = '/';
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET' && AuthController::serveAvatarIfExists($path)) {
    exit;
}

if ($path === '/' || $path === '') {
    header('Content-Type: text/html; charset=utf-8');
    $currentUser = AuthController::currentUser($pdo);
    require __DIR__ . '/views/home.php';
    exit;
}

$auth = new AuthController($pdo, $config);
if ($path === '/auth/login' && $method === 'GET') {
    $auth->loginPage();
    exit;
}
if ($path === '/auth/email' && $method === 'POST') {
    $auth->emailLogin();
    exit;
}
if ($path === '/auth/register' && $method === 'POST') {
    $auth->register();
    exit;
}
if ($path === '/auth/vk' && $method === 'GET') {
    $auth->redirectVk();
    exit;
}
if ($path === '/auth/vk/callback' && $method === 'GET') {
    $auth->callbackVk();
    exit;
}
if ($path === '/auth/yandex' && $method === 'GET') {
    $auth->redirectYandex();
    exit;
}
if ($path === '/auth/yandex/callback' && $method === 'GET') {
    $auth->callbackYandex();
    exit;
}
if ($path === '/auth/telegram' && $method === 'POST') {
    $auth->telegramLogin();
    exit;
}
if ($path === '/auth/logout' && $method === 'POST') {
    $auth->logout();
    exit;
}
if (($path === '/profile' || $path === '/cabinet') && $method === 'GET') {
    $auth->profilePage();
    exit;
}
if ($path === '/profile/settings' && $method === 'POST') {
    $auth->saveProfileSettings();
    exit;
}
if ($path === '/profile/password' && $method === 'POST') {
    $auth->changePassword();
    exit;
}
if ($path === '/profile/password/init' && $method === 'POST') {
    $auth->setInitialPassword();
    exit;
}
if ($path === '/profile/avatar' && $method === 'POST') {
    $auth->uploadAvatar();
    exit;
}
if ($path === '/profile/unlink-social' && $method === 'POST') {
    $auth->unlinkSocial();
    exit;
}
if (preg_match('#^/profile/orders/(\d+)/cancel$#', $path, $m) && $method === 'POST') {
    $auth->cancelOrder((int) $m[1]);
    exit;
}

if (str_starts_with($path, '/api/') && !str_starts_with($path, '/api/v1')) {
    (new ApiController($pdo, $config))->dispatch($method, $path);
    exit;
}

if (str_starts_with($path, '/admin')) {
    $admin = new AdminController($pdo, $config);
    if ($path === '/admin/login' && $method === 'POST') {
        $admin->login();
        exit;
    }
    if ($path === '/admin/logout' && $method === 'POST') {
        $admin->logout();
        exit;
    }
    if ($path === '/admin') {
        $admin->showPage();
        exit;
    }
    if (preg_match('#^/admin/orders/(\d+)/status$#', $path, $m) && $method === 'POST') {
        $admin->updateOrderStatus((int) $m[1]);
        exit;
    }
}

$menu = new MenuController($pdo);
$orders = new OrderController($pdo);
$delivery = new DeliveryController($pdo);
$geocode = new GeocodeController();

$router = new Router();
$router
    ->get('/api/v1/menu', fn () => $menu->list())
    ->get('/api/v1/menu/{id}', fn (string $id) => $menu->one($id))
    ->get('/api/v1/delivery-zones', fn () => $delivery->zones())
    ->get('/api/v1/geocode', fn () => $geocode->geocode())
    ->get('/api/v1/me/delivery-prefs', fn () => $orders->meDeliveryPrefs())
    ->get('/api/v1/me/orders/active', fn () => $orders->meActiveOrder())
    ->get('/api/v1/me/orders', fn () => $orders->meOrders())
    ->post('/api/v1/orders', fn () => $orders->create())
    ->get('/api/v1/orders', fn () => $orders->byPhone())
    ->get('/api/v1/orders/{id}', fn (string $id) => $orders->one($id));

$router->dispatch($method, $path);

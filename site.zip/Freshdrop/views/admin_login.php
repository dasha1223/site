<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход — админка</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: "DM Sans", system-ui, sans-serif;
            background: #0a0b10;
            color: #e8eaef;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        .box {
            width: 100%;
            max-width: 380px;
            padding: 2rem;
            border-radius: 20px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
        }
        h1 { margin: 0 0 0.5rem; font-size: 1.35rem; }
        p { margin: 0 0 1.25rem; color: #8b95a5; font-size: 0.9rem; }
        label { display: block; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em; color: #8b95a5; margin-bottom: 0.35rem; }
        input[type="password"] {
            width: 100%;
            padding: 0.75rem 0.85rem;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(0,0,0,0.3);
            color: #fff;
            font: inherit;
            margin-bottom: 1rem;
        }
        input:focus { outline: none; border-color: #7c5cff; box-shadow: 0 0 0 3px rgba(124,92,255,0.2); }
        button {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 14px;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
            color: #0a0b10;
            background: linear-gradient(135deg, #34d399, #22d3ee);
        }
        .err { color: #fb7185; font-size: 0.88rem; margin-bottom: 1rem; }
        a { color: #22d3ee; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="box">
    <h1>Админ-панель</h1>
    <p>Введите пароль для просмотра заказов.</p>
    <?php if (!empty($error)): ?>
        <div class="err"><?= htmlspecialchars((string) $error, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
    <?php endif; ?>
    <form method="post" action="<?= htmlspecialchars($adminLoginUrl ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
        <label for="password">Пароль</label>
        <input type="password" id="password" name="password" required autocomplete="current-password" autofocus>
        <button type="submit">Войти</button>
    </form>
    <p style="margin-top:1.25rem;margin-bottom:0"><a href="<?= htmlspecialchars($siteHomeUrl ?? '/', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">← На сайт</a></p>
</div>
</body>
</html>

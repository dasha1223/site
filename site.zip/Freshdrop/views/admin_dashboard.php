<?php
declare(strict_types=1);

/** @var array<int, array<string, mixed>> $orders */

function admin_h(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$home = $base === '' ? '/' : $base . '/';
$logout = $base === '' ? '/admin/logout' : $base . '/admin/logout';

function admin_money_ru(int $cents): string
{
    return number_format($cents / 100, 0, ',', ' ') . ' ₽';
}

$statusOptions = [
    OrderStatus::ACCEPTED => 'принят',
    OrderStatus::PREPARING => 'готовится',
    OrderStatus::DELIVERING => 'в доставке',
    OrderStatus::RECEIVED => 'получен',
    OrderStatus::CANCELLED => 'отменён',
];

$adminStatusUrl = static function (int $orderId) use ($base): string {
    $p = '/admin/orders/' . $orderId . '/status';
    return $base === '' ? $p : $base . $p;
};
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Заказы — админка</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "DM Sans", system-ui, sans-serif;
            background: #07080d;
            color: #e8eaef;
            line-height: 1.5;
            min-height: 100vh;
        }
        .top {
            position: sticky;
            top: 0;
            z-index: 10;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            padding: 1rem 1.25rem;
            background: rgba(7,8,13,0.85);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .top h1 { margin: 0; font-size: 1.15rem; font-weight: 700; }
        .top form { margin: 0; }
        .btn {
            padding: 0.45rem 0.9rem;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(255,255,255,0.05);
            color: #e8eaef;
            font: inherit;
            font-size: 0.85rem;
            cursor: pointer;
        }
        .btn:hover { background: rgba(255,255,255,0.1); }
        .btn-link {
            border: none;
            background: transparent;
            color: #22d3ee;
            text-decoration: underline;
            cursor: pointer;
            font: inherit;
            font-size: 0.9rem;
        }
        .wrap { max-width: 1100px; margin: 0 auto; padding: 1.25rem; }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
        }
        th, td {
            text-align: left;
            padding: 0.75rem 0.65rem;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            vertical-align: top;
        }
        th {
            color: #8b95a5;
            font-weight: 600;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }
        tr:hover td { background: rgba(255,255,255,0.02); }
        .num { font-variant-numeric: tabular-nums; white-space: nowrap; }
        .addr { max-width: 280px; color: #c4c9d4; }
        .items { color: #9aa3b2; font-size: 0.82rem; }
        .items ul { margin: 0.35rem 0 0; padding-left: 1.1rem; }
        .status {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            background: rgba(52, 211, 153, 0.15);
            color: #34d399;
        }
        .status-form {
            margin-top: 0.45rem;
            display: flex;
            gap: 0.35rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .status-form select {
            padding: 0.35rem 0.5rem;
            border-radius: 8px;
            border: 1px solid rgba(255,255,255,0.12);
            background: rgba(0,0,0,0.35);
            color: #e8eaef;
            font: inherit;
            font-size: 0.8rem;
        }
        .status-form .btn { padding: 0.35rem 0.65rem; font-size: 0.78rem; }
        @media (max-width: 900px) {
            table, thead, tbody, th, td, tr { display: block; }
            thead { display: none; }
            tr {
                margin-bottom: 1rem;
                padding: 1rem;
                border-radius: 14px;
                background: rgba(255,255,255,0.03);
                border: 1px solid rgba(255,255,255,0.06);
            }
            td {
                border: none;
                padding: 0.35rem 0;
            }
            td::before {
                display: block;
                font-size: 0.7rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                color: #8b95a5;
                margin-bottom: 0.15rem;
            }
            td:nth-child(1)::before { content: '№'; }
            td:nth-child(2)::before { content: 'Клиент'; }
            td:nth-child(3)::before { content: 'Телефон'; }
            td:nth-child(4)::before { content: 'Куда везти'; }
            td:nth-child(5)::before { content: 'Состав'; }
            td:nth-child(6)::before { content: 'Сумма'; }
            td:nth-child(7)::before { content: 'Время'; }
            .addr { max-width: none; }
        }
    </style>
</head>
<body>
<header class="top">
    <h1>Заказы</h1>
    <div style="display:flex;align-items:center;gap:0.75rem">
        <a class="btn-link" href="<?= admin_h($home) ?>">На сайт</a>
        <form method="post" action="<?= admin_h($logout) ?>">
            <button type="submit" class="btn">Выйти</button>
        </form>
    </div>
</header>
<div class="wrap">
    <?php if ($orders === []): ?>
        <p style="color:#8b95a5">Пока нет заказов.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Имя</th>
                    <th>Телефон</th>
                    <th>Адрес</th>
                    <th>Что заказали</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                    <th>Время</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
                <?php $curStatus = OrderStatus::normalize((string) $o['status']); ?>
                <tr>
                    <td class="num"><strong>#<?= (int) $o['id'] ?></strong></td>
                    <td><?= admin_h((string) $o['customer_name']) ?></td>
                    <td class="num"><?= admin_h((string) $o['phone']) ?></td>
                    <td class="addr">
                        <?= admin_h((string) $o['address']) ?>
                        <?php if (!empty($o['comment'])): ?>
                            <div style="margin-top:0.35rem;color:#8b95a5;font-size:0.82rem">💬 <?= admin_h((string) $o['comment']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="items">
                        <?php
                        /** @var list<array<string, mixed>> $items */
                        $items = $o['items'] ?? [];
                        ?>
                        <?php if ($items === []): ?>
                            —
                        <?php else: ?>
                            <ul>
                                <?php foreach ($items as $it): ?>
                                    <li><?= admin_h((string) $it['dish_name']) ?> × <?= (int) $it['quantity'] ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </td>
                    <td class="num"><?= admin_h(admin_money_ru((int) $o['total_cents'])) ?></td>
                    <td>
                        <span class="status"><?= admin_h(OrderStatus::labelRu($curStatus)) ?></span>
                        <?php if ($curStatus !== OrderStatus::CANCELLED && $curStatus !== OrderStatus::RECEIVED): ?>
                        <form class="status-form" method="post" action="<?= admin_h($adminStatusUrl((int) $o['id'])) ?>">
                            <select name="status" aria-label="Новый статус">
                                <?php foreach ($statusOptions as $code => $label): ?>
                                    <?php if ($code === OrderStatus::CANCELLED) { continue; } ?>
                                    <option value="<?= admin_h($code) ?>"<?= $curStatus === $code ? ' selected' : '' ?>><?= admin_h($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn">Сохранить</button>
                        </form>
                        <?php endif; ?>
                    </td>
                    <td class="num" style="white-space:nowrap"><?= admin_h((string) $o['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>

<?php
declare(strict_types=1);
/** @var array<string,mixed>|null $currentUser */
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$url = static fn (string $path): string => ($base === '' ? '' : $base) . '/' . ltrim($path, '/');
$loggedInUserId = !empty($currentUser) ? (int) ($currentUser['id'] ?? 0) : 0;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FreshDrop — доставка еды</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
    <style>
        :root {
            --bg0: #07080d;
            --bg1: #0f111a;
            --surface: rgba(255, 255, 255, 0.04);
            --surface2: rgba(255, 255, 255, 0.07);
            --stroke: rgba(255, 255, 255, 0.08);
            --text: #f4f5f7;
            --muted: #9aa3b2;
            --accent: #7c5cff;
            --accent2: #22d3ee;
            --success: #34d399;
            --danger: #fb7185;
            --radius: 20px;
            --shadow: 0 24px 80px rgba(0, 0, 0, 0.45);
            font-family: "DM Sans", system-ui, sans-serif;
        }

        *, *::before, *::after { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--text);
            background: var(--bg0);
            line-height: 1.55;
            overflow-x: hidden;
        }

        .noise {
            pointer-events: none;
            position: fixed;
            inset: 0;
            opacity: 0.04;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
            z-index: 0;
        }

        .aurora {
            position: fixed;
            inset: -40% -20%;
            z-index: 0;
            background:
                radial-gradient(ellipse 50% 40% at 20% 10%, rgba(124, 92, 255, 0.35), transparent 55%),
                radial-gradient(ellipse 45% 35% at 85% 15%, rgba(34, 211, 238, 0.2), transparent 50%),
                radial-gradient(ellipse 60% 50% at 50% 100%, rgba(124, 92, 255, 0.12), transparent 55%);
            animation: auroraShift 18s ease-in-out infinite alternate;
        }

        @keyframes auroraShift {
            0% { transform: translate3d(0, 0, 0) scale(1); }
            100% { transform: translate3d(2%, -1%, 0) scale(1.05); }
        }

        .wrap {
            position: relative;
            z-index: 1;
            max-width: 1120px;
            margin: 0 auto;
            padding: 1.5rem 1.25rem 7rem;
        }

        .topbar-auth {
            display: flex;
            justify-content: flex-end;
            gap: 0.55rem;
            margin-bottom: 0.5rem;
        }

        .auth-btn {
            border: 1px solid rgba(255,255,255,0.14);
            background: rgba(255,255,255,0.05);
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 0.8rem;
            border-radius: 12px;
            font-size: 0.82rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .auth-btn:hover {
            background: rgba(255,255,255,0.1);
        }

        header.hero {
            padding: 2.5rem 0 2rem;
            animation: heroIn 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) both;
        }

        @keyframes heroIn {
            from { opacity: 0; transform: translateY(24px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.35rem 0.75rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: var(--accent2);
            background: rgba(34, 211, 238, 0.1);
            border: 1px solid rgba(34, 211, 238, 0.25);
            margin-bottom: 1rem;
        }

        .badge-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--accent2);
            box-shadow: 0 0 12px var(--accent2);
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(0.85); }
        }

        h1 {
            font-size: clamp(2rem, 5vw, 2.75rem);
            font-weight: 700;
            letter-spacing: -0.03em;
            margin: 0 0 0.75rem;
            background: linear-gradient(120deg, #fff 0%, #c4c9d4 45%, var(--accent2) 100%);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .lead {
            color: var(--muted);
            font-size: 1.05rem;
            max-width: 36rem;
            margin: 0;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin: 2.5rem 0 1rem;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .section-title::after {
            content: "";
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, var(--stroke), transparent);
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.1rem;
        }

        .dish-card {
            position: relative;
            border-radius: var(--radius);
            background: var(--surface);
            border: 1px solid var(--stroke);
            backdrop-filter: blur(12px);
            overflow: hidden;
            box-shadow: var(--shadow);
            animation: cardIn 0.6s cubic-bezier(0.2, 0.85, 0.2, 1) both;
            animation-delay: var(--d, 0s);
            transition: transform 0.35s cubic-bezier(0.2, 0.8, 0.2, 1), border-color 0.35s, box-shadow 0.35s;
        }

        .dish-card {
            cursor: pointer;
        }

        .dish-card:hover {
            transform: translateY(-6px);
            border-color: rgba(124, 92, 255, 0.35);
            box-shadow: 0 28px 90px rgba(124, 92, 255, 0.12), var(--shadow);
        }

        .dish-modal-backdrop {
            position: fixed;
            inset: 0;
            z-index: 70;
            background: rgba(0, 0, 0, 0.65);
            backdrop-filter: blur(4px);
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .dish-modal-backdrop.is-open {
            opacity: 1;
            pointer-events: auto;
        }

        .dish-modal {
            position: fixed;
            left: 50%;
            top: 50%;
            z-index: 71;
            width: min(92vw, 480px);
            max-height: 85vh;
            overflow-y: auto;
            transform: translate(-50%, -48%) scale(0.96);
            opacity: 0;
            pointer-events: none;
            border-radius: 22px;
            border: 1px solid var(--stroke);
            background: rgba(12, 14, 22, 0.96);
            backdrop-filter: blur(16px);
            box-shadow: var(--shadow);
            padding: 1.25rem 1.35rem 1.35rem;
            transition: transform 0.35s cubic-bezier(0.2, 0.85, 0.2, 1), opacity 0.3s ease;
        }

        .dish-modal.is-open {
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
            pointer-events: auto;
        }

        .dish-modal__head {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 0.75rem;
            margin-bottom: 0.75rem;
        }

        .dish-modal__head h3 {
            margin: 0;
            font-size: 1.25rem;
            letter-spacing: -0.02em;
        }

        .dish-modal__close {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            border: 1px solid var(--stroke);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            font-size: 1.35rem;
            cursor: pointer;
            line-height: 1;
        }

        .dish-modal__img {
            border-radius: 14px;
            overflow: hidden;
            aspect-ratio: 16/10;
            margin-bottom: 1rem;
            background: #1a1d2e;
        }

        .dish-modal__img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .dish-modal__thumbs {
            display: flex;
            gap: 0.45rem;
            margin: -0.3rem 0 0.9rem;
            overflow-x: auto;
        }

        .dish-modal__thumb {
            width: 68px;
            height: 52px;
            border-radius: 10px;
            border: 1px solid var(--stroke);
            overflow: hidden;
            padding: 0;
            background: rgba(255,255,255,0.04);
            cursor: pointer;
            flex: 0 0 auto;
        }

        .dish-modal__thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .dish-modal__thumb.is-active {
            border-color: rgba(34, 211, 238, 0.7);
            box-shadow: 0 0 0 2px rgba(34, 211, 238, 0.25);
        }

        .dish-modal__label {
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--muted);
            margin: 0 0 0.35rem;
        }

        .dish-modal__text {
            margin: 0 0 1rem;
            color: var(--muted);
            font-size: 0.9rem;
        }

        .dish-modal__row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        @keyframes cardIn {
            from {
                opacity: 0;
                transform: translateY(20px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .dish-card__img {
            position: relative;
            aspect-ratio: 4 / 3;
            overflow: hidden;
            background: linear-gradient(145deg, #1a1d2e, #12141c);
        }

        .dish-card__img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transform: scale(1.02);
            transition: transform 0.55s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        .dish-card:hover .dish-card__img img {
            transform: scale(1.08);
        }

        .dish-card__img::after {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 40%, rgba(7, 8, 13, 0.85));
            pointer-events: none;
        }

        .dish-card__body {
            padding: 1rem 1.1rem 1.15rem;
        }

        .dish-name {
            font-weight: 600;
            font-size: 1.05rem;
            margin: 0 0 0.35rem;
            letter-spacing: -0.02em;
        }

        .dish-desc {
            font-size: 0.85rem;
            color: var(--muted);
            margin: 0 0 1rem;
            min-height: 2.6em;
        }

        .dish-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
        }

        .price {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--success);
            letter-spacing: -0.02em;
        }

        .btn-add {
            position: relative;
            overflow: hidden;
            border: none;
            border-radius: 12px;
            padding: 0.55rem 1rem;
            font: inherit;
            font-size: 0.82rem;
            font-weight: 600;
            cursor: pointer;
            color: #fff;
            background: linear-gradient(135deg, var(--accent), #5b8cff);
            box-shadow: 0 8px 24px rgba(124, 92, 255, 0.35);
            transition: transform 0.2s, filter 0.2s;
        }

        .btn-add:hover:not(:disabled) {
            filter: brightness(1.08);
            transform: translateY(-1px);
        }

        .btn-add:active:not(:disabled) {
            transform: scale(0.97);
        }

        .btn-add:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            filter: grayscale(0.3);
        }

        .btn-add::after {
            content: "";
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at var(--rx, 50%) var(--ry, 50%), rgba(255,255,255,0.35), transparent 45%);
            opacity: 0;
            transition: opacity 0.4s;
        }

        .btn-add:active::after {
            opacity: 1;
        }

        .zones-grid {
            display: grid;
            gap: 0.75rem;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        }

        .zone-card {
            padding: 1rem 1.15rem;
            border-radius: 16px;
            background: var(--surface2);
            border: 1px solid var(--stroke);
            font-size: 0.9rem;
            color: var(--muted);
            animation: cardIn 0.55s ease both;
            animation-delay: var(--dz, 0s);
            transition: transform 0.3s, border-color 0.3s;
        }

        .zone-card:hover {
            transform: translateY(-3px);
            border-color: rgba(34, 211, 238, 0.25);
        }

        .zone-card strong {
            display: block;
            color: var(--text);
            font-size: 1rem;
            margin-bottom: 0.35rem;
        }

        .cart-backdrop {
            position: fixed;
            inset: 0;
            z-index: 58;
            background: rgba(0, 0, 0, 0.5);
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.35s ease;
            backdrop-filter: blur(3px);
        }

        .cart-backdrop.is-open {
            opacity: 1;
            pointer-events: auto;
        }

        .fab-cart {
            position: fixed;
            right: 1rem;
            bottom: 1rem;
            z-index: 60;
            width: 58px;
            height: 58px;
            border-radius: 50%;
            border: none;
            cursor: pointer;
            color: #fff;
            background: linear-gradient(135deg, var(--accent), #5b8cff);
            box-shadow: 0 14px 44px rgba(124, 92, 255, 0.42);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .fab-cart--inner {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
        }

        .fab-cart:hover {
            transform: scale(1.06);
        }

        .fab-cart:active {
            transform: scale(0.96);
        }

        .fab-cart svg {
            width: 26px;
            height: 26px;
            display: block;
        }

        .fab-cart .cart-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            min-width: 1.35rem;
            height: 1.35rem;
            padding: 0 0.35rem;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #34d399, #22d3ee);
            color: #0a0b10;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
        }

        .cart-panel {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            z-index: 59;
            width: min(100%, 420px);
            max-width: 100%;
            border-radius: 0;
            border-left: 1px solid var(--stroke);
            background: rgba(12, 14, 22, 0.94);
            backdrop-filter: blur(18px);
            box-shadow: -16px 0 60px rgba(0, 0, 0, 0.5);
            padding: 1.15rem 1.25rem 1.5rem;
            overflow-y: auto;
            transform: translateX(105%);
            opacity: 0;
            pointer-events: none;
            transition: transform 0.45s cubic-bezier(0.2, 0.85, 0.2, 1), opacity 0.3s ease;
        }

        .cart-panel.is-open {
            transform: translateX(0);
            opacity: 1;
            pointer-events: auto;
        }

        .cart-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.75rem;
            gap: 0.5rem;
        }

        .cart-head h2 {
            margin: 0;
            font-size: 1rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .cart-close {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            border: 1px solid var(--stroke);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            font-size: 1.35rem;
            line-height: 1;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s, border-color 0.2s;
        }

        .cart-close:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.15);
        }

        .cart-badge {
            min-width: 1.5rem;
            height: 1.5rem;
            padding: 0 0.4rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--accent), #5b8cff);
            color: #fff;
            transition: transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .cart-badge.pop {
            transform: scale(1.2);
        }

        .cart-line {
            display: flex;
            justify-content: space-between;
            gap: 0.5rem;
            font-size: 0.88rem;
            margin-bottom: 0.4rem;
            color: var(--muted);
        }

        .cart-line span:last-child {
            color: var(--text);
            font-weight: 500;
        }

        #cart-total {
            margin: 0.6rem 0 0.5rem;
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--success);
        }

        .cart-actions {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .btn-clear-cart {
            flex: 1;
            min-width: 0;
            padding: 0.55rem 0.75rem;
            border-radius: 12px;
            border: 1px solid rgba(251, 113, 133, 0.35);
            background: rgba(251, 113, 133, 0.08);
            color: var(--danger);
            font: inherit;
            font-size: 0.82rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s, border-color 0.2s;
        }

        .btn-clear-cart:hover:not(:disabled) {
            background: rgba(251, 113, 133, 0.15);
            border-color: rgba(251, 113, 133, 0.55);
        }

        .btn-clear-cart:disabled {
            opacity: 0.35;
            cursor: not-allowed;
        }

        label {
            font-size: 0.72rem;
            font-weight: 600;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: var(--muted);
            display: block;
            margin-bottom: 0.35rem;
        }

        input, textarea, select {
            width: 100%;
            padding: 0.65rem 0.8rem;
            border-radius: 12px;
            border: 1px solid var(--stroke);
            background: rgba(0, 0, 0, 0.25);
            color: var(--text);
            font: inherit;
            margin-bottom: 0.65rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            cursor: pointer;
            max-width: 100%;
            min-width: 0;
            padding-right: 2.4rem;
            background-image:
                linear-gradient(45deg, transparent 50%, #9aa3b2 50%),
                linear-gradient(135deg, #9aa3b2 50%, transparent 50%);
            background-position:
                calc(100% - 17px) calc(50% + 1px),
                calc(100% - 11px) calc(50% + 1px);
            background-size: 6px 6px, 6px 6px;
            background-repeat: no-repeat;
        }

        #delivery-zone {
            display: block;
            width: 100%;
        }

        #checkout-map {
            height: 160px;
            width: 100%;
            border-radius: 12px;
            border: 1px solid var(--stroke);
            margin: 0 0 0.65rem;
            overflow: hidden;
            z-index: 1;
        }

        .map-hint {
            font-size: 0.75rem;
            color: var(--muted);
            margin: -0.35rem 0 0.55rem;
        }

        select:hover {
            border-color: rgba(124, 92, 255, 0.35);
            background-color: rgba(20, 24, 36, 0.6);
        }

        select option {
            background: #121624;
            color: var(--text);
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: rgba(124, 92, 255, 0.45);
            box-shadow: 0 0 0 3px rgba(124, 92, 255, 0.15);
        }

        .btn-order {
            width: 100%;
            margin-top: 0.35rem;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 14px;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
            color: #0a0b10;
            background: linear-gradient(135deg, #34d399, #22d3ee);
            box-shadow: 0 12px 32px rgba(52, 211, 153, 0.25);
            transition: transform 0.2s, filter 0.2s;
        }

        .btn-order:hover {
            filter: brightness(1.05);
            transform: translateY(-1px);
        }

        .btn-order:active {
            transform: scale(0.98);
        }

        .msg { margin-top: 0.75rem; font-size: 0.88rem; min-height: 1.2em; }
        .msg.ok { color: var(--success); }
        .msg.err { color: var(--danger); }

        .load-state {
            padding: 3rem 1rem;
            text-align: center;
            color: var(--muted);
            animation: pulse 1.5s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
            .aurora, .badge-dot, .dish-card, .zone-card, header.hero { animation: none !important; }
            .dish-card { opacity: 1; transform: none; }
            .dish-card:hover { transform: none; }
            .cart-panel, .cart-backdrop { transition: none !important; }
        }

        @media (max-width: 640px) {
            .cart-panel {
                top: auto;
                left: 0;
                right: 0;
                bottom: 0;
                width: 100%;
                max-height: 88vh;
                border-radius: 22px 22px 0 0;
                border-left: none;
                border-top: 1px solid var(--stroke);
                transform: translateY(110%);
                box-shadow: 0 -20px 60px rgba(0, 0, 0, 0.55);
            }

            .cart-panel.is-open {
                transform: translateY(0);
            }

            .fab-cart {
                right: 1rem;
                bottom: 1rem;
            }
        }

        @media (min-width: 900px) {
            .fab-cart {
                right: 2rem;
                bottom: 2rem;
            }
        }
    </style>
</head>
<body>
<div class="aurora" aria-hidden="true"></div>
<div class="noise" aria-hidden="true"></div>

<div class="wrap">
    <div class="topbar-auth">
        <?php if (!empty($currentUser)): ?>
            <a class="auth-btn" href="<?= htmlspecialchars($url('/profile'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>#orders">Мои заказы</a>
            <a class="auth-btn" href="<?= htmlspecialchars($url('/profile'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
                👤 <?= htmlspecialchars((string) ($currentUser['display_name'] ?? 'Кабинет'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
            </a>
        <?php else: ?>
            <a class="auth-btn" href="<?= htmlspecialchars($url('/auth/login'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">Войти</a>
        <?php endif; ?>
    </div>
    <header class="hero">
        <div class="badge"><span class="badge-dot"></span> Доставка 30–45 мин</div>
        <h1>Еда, которая приезжает горячей</h1>
        <p class="lead">Соберите заказ из меню ниже — курьер уже на старте.</p>
    </header>

    <section aria-labelledby="menu-heading">
        <h2 id="menu-heading" class="section-title">Меню</h2>
        <div id="menu"><div class="load-state">Загружаем меню…</div></div>
    </section>

    <section aria-labelledby="zones-heading">
        <h2 id="zones-heading" class="section-title">Зоны доставки</h2>
        <div id="zones" class="zones-grid"><div class="load-state" style="grid-column:1/-1">Загрузка…</div></div>
    </section>
</div>

<button type="button" class="fab-cart" id="cart-fab" aria-expanded="false" aria-controls="cart-panel" title="Открыть корзину">
    <span class="fab-cart--inner">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
        </svg>
        <span class="cart-badge" id="cart-badge">0</span>
    </span>
</button>
<div class="cart-backdrop" id="cart-backdrop" hidden></div>

<div class="cart-panel" id="cart-panel" role="dialog" aria-modal="true" aria-labelledby="cart-title" aria-hidden="true">
    <div class="cart-head">
        <h2 id="cart-title">Корзина</h2>
        <button type="button" class="cart-close" id="cart-close" aria-label="Закрыть корзину">×</button>
    </div>
    <div id="cart-lines"></div>
    <p id="cart-total"></p>
    <div class="cart-actions">
        <button type="button" class="btn-clear-cart" id="cart-clear" disabled>Очистить корзину</button>
    </div>
    <label for="cust-name">Имя</label>
    <input type="text" id="cust-name" placeholder="Как к вам обращаться" autocomplete="name">
    <label for="cust-phone">Телефон</label>
    <input type="tel" id="cust-phone" placeholder="+7 (999) 000-00-00" inputmode="numeric" autocomplete="tel" maxlength="18">
    <label for="cust-addr">Адрес доставки</label>
    <textarea id="cust-addr" rows="2" placeholder="Улица, дом, подъезд, этаж" autocomplete="street-address"></textarea>
    <p class="map-hint">Укажите адрес — точка появится на карте. Можно кликнуть по карте, чтобы уточнить.</p>
    <div id="checkout-map" aria-label="Карта адреса доставки"></div>
    <label for="cust-comment">Комментарий</label>
    <input type="text" id="cust-comment" placeholder="Не звонить в дверь">
    <label for="delivery-zone">Зона доставки</label>
    <select id="delivery-zone"></select>
    <button type="button" class="btn-order" id="submit-order">Оформить заказ</button>
    <div class="msg" id="order-msg"></div>
</div>

<div class="dish-modal-backdrop" id="dish-modal-backdrop" hidden></div>
<div class="dish-modal" id="dish-modal" role="dialog" aria-modal="true" aria-labelledby="dish-modal-title" aria-hidden="true">
    <div class="dish-modal__head">
        <h3 id="dish-modal-title"></h3>
        <button type="button" class="dish-modal__close" id="dish-modal-close" aria-label="Закрыть">×</button>
    </div>
    <div class="dish-modal__img"><img id="dish-modal-img" src="" alt=""></div>
    <div class="dish-modal__thumbs" id="dish-modal-thumbs"></div>
    <p class="dish-modal__label">Описание</p>
    <p class="dish-modal__text" id="dish-modal-desc"></p>
    <p class="dish-modal__label">Состав</p>
    <p class="dish-modal__text" id="dish-modal-composition"></p>
    <div class="dish-modal__row">
        <span class="price" id="dish-modal-price"></span>
        <button type="button" class="btn-add" id="dish-modal-add">В корзину</button>
    </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>
(function () {
    const baseDir = window.location.pathname.replace(/[^/]*$/, '');
    const api = (path) => window.location.origin + baseDir + path.replace(/^\//, '');
    const loggedInUserId = <?= $loggedInUserId ?>;
    const LS_CHECKOUT = 'freshdrop_checkout_v1';
    const fetchCf = { credentials: 'same-origin' };
    const cart = new Map();
    const PLACEHOLDER = 'data:image/svg+xml,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="480" viewBox="0 0 640 480"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="%231a1d2e"/><stop offset="1" stop-color="%2312141c"/></linearGradient></defs><rect width="640" height="480" fill="url(%23g)"/><text x="320" y="248" text-anchor="middle" fill="%239aa3b2" font-family="system-ui,sans-serif" font-size="18">Нет фото</text></svg>'
    );

    const cartFab = document.getElementById('cart-fab');
    const cartPanel = document.getElementById('cart-panel');
    const cartBackdrop = document.getElementById('cart-backdrop');
    const cartClose = document.getElementById('cart-close');
    const phoneInput = document.getElementById('cust-phone');
    const dishModal = document.getElementById('dish-modal');
    const dishModalBackdrop = document.getElementById('dish-modal-backdrop');
    const dishModalClose = document.getElementById('dish-modal-close');
    const dishModalAdd = document.getElementById('dish-modal-add');
    const deliveryZoneSelect = document.getElementById('delivery-zone');
    const addrInput = document.getElementById('cust-addr');
    let modalDish = null;
    let checkoutMap = null;
    let checkoutMarker = null;
    let addressLat = 55.7558;
    let addressLng = 37.6173;
    let geocodeTimer = null;
    const RESTAURANT = [55.7558, 37.6173];
    let selectedZone = null;
    let zonesState = [];
    const dishById = new Map();

    function money(n) {
        return (n / 100).toLocaleString('ru-RU', { style: 'currency', currency: 'RUB', maximumFractionDigits: 0 });
    }

    function escapeHtml(s) {
        const d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function escapeAttr(s) {
        return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    }

    function digitsRuPhone(raw) {
        let d = String(raw).replace(/\D/g, '');
        if (d.startsWith('8')) d = '7' + d.slice(1);
        if (d.length === 10 && d[0] === '9') d = '7' + d;
        if (d.length > 0 && d[0] !== '7') d = '7' + d.replace(/^7+/, '');
        return d.slice(0, 11);
    }

    function formatRuPhoneMask(digits) {
        if (digits.length <= 1) return '+7';
        const r = digits.slice(1);
        let o = '+7 (';
        o += r.slice(0, Math.min(3, r.length));
        if (r.length <= 3) return o + (r.length === 3 ? ') ' : '');
        o += ') ' + r.slice(3, Math.min(6, r.length));
        if (r.length <= 6) return o;
        o += '-' + r.slice(6, Math.min(8, r.length));
        if (r.length <= 8) return o;
        return o + '-' + r.slice(8, 10);
    }

    function phoneForApi(value) {
        const d = digitsRuPhone(value);
        return d.length === 11 ? ('+' + d) : '';
    }

    function bindPhoneMask(input) {
        input.addEventListener('focus', () => {
            if (!input.value.trim()) input.value = '+7';
        });
        input.addEventListener('blur', () => {
            if (digitsRuPhone(input.value).length <= 1) input.value = '';
        });
        input.addEventListener('input', () => {
            const d = digitsRuPhone(input.value);
            input.value = formatRuPhoneMask(d);
        });
    }

    function setCartOpen(open) {
        cartPanel.classList.toggle('is-open', open);
        cartBackdrop.classList.toggle('is-open', open);
        cartFab.setAttribute('aria-expanded', open ? 'true' : 'false');
        cartPanel.setAttribute('aria-hidden', open ? 'false' : 'true');
        if (open) {
            cartBackdrop.removeAttribute('hidden');
            document.body.style.overflow = 'hidden';
            setTimeout(() => {
                initCheckoutMap();
                if (checkoutMap) checkoutMap.invalidateSize();
                if (addrInput.value.trim().length >= 5) geocodeAddress();
            }, 80);
            setTimeout(() => cartClose.focus(), 50);
        } else {
            cartBackdrop.setAttribute('hidden', '');
            document.body.style.overflow = '';
            cartFab.focus();
        }
    }

    cartFab.addEventListener('click', () => setCartOpen(!cartPanel.classList.contains('is-open')));
    cartBackdrop.addEventListener('click', () => setCartOpen(false));
    cartClose.addEventListener('click', () => setCartOpen(false));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (dishModal.classList.contains('is-open')) {
                setDishModalOpen(false);
                return;
            }
            if (cartPanel.classList.contains('is-open')) {
                setCartOpen(false);
            }
        }
    });

    bindPhoneMask(phoneInput);

    function initCheckoutMap() {
        if (checkoutMap || typeof L === 'undefined') return;
        const el = document.getElementById('checkout-map');
        if (!el) return;
        checkoutMap = L.map(el, { zoomControl: true, attributionControl: false });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(checkoutMap);
        L.marker(RESTAURANT).addTo(checkoutMap).bindPopup('FreshDrop');
        checkoutMarker = L.marker([addressLat, addressLng], { draggable: true }).addTo(checkoutMap);
        checkoutMarker.on('dragend', () => {
            const p = checkoutMarker.getLatLng();
            addressLat = p.lat;
            addressLng = p.lng;
        });
        checkoutMap.setView([addressLat, addressLng], 13);
        setTimeout(() => checkoutMap.invalidateSize(), 120);
    }

    function setMapPoint(lat, lng, zoom) {
        addressLat = lat;
        addressLng = lng;
        if (!checkoutMap) initCheckoutMap();
        if (!checkoutMap) return;
        if (!checkoutMarker) {
            checkoutMarker = L.marker([lat, lng], { draggable: true }).addTo(checkoutMap);
            checkoutMarker.on('dragend', () => {
                const p = checkoutMarker.getLatLng();
                addressLat = p.lat;
                addressLng = p.lng;
            });
        } else {
            checkoutMarker.setLatLng([lat, lng]);
        }
        checkoutMap.setView([lat, lng], zoom || 15);
    }

    function geocodeAddress() {
        const q = addrInput.value.trim();
        if (q.length < 5) return;
        fetch(api('api/v1/geocode?address=' + encodeURIComponent(q)), fetchCf)
            .then(r => r.json())
            .then(j => {
                if (!j.success || !j.data) return;
                setMapPoint(j.data.lat, j.data.lng, 15);
            })
            .catch(() => {});
    }

    addrInput.addEventListener('input', () => {
        clearTimeout(geocodeTimer);
        geocodeTimer = setTimeout(geocodeAddress, 700);
    });

    function setDishModalOpen(open) {
        dishModal.classList.toggle('is-open', open);
        dishModalBackdrop.classList.toggle('is-open', open);
        dishModal.setAttribute('aria-hidden', open ? 'false' : 'true');
        if (open) {
            dishModalBackdrop.removeAttribute('hidden');
            document.body.style.overflow = 'hidden';
        } else {
            dishModalBackdrop.setAttribute('hidden', '');
            document.body.style.overflow = '';
            modalDish = null;
        }
    }

    function openDishModal(dish) {
        modalDish = dish;
        document.getElementById('dish-modal-title').textContent = dish.name;
        document.getElementById('dish-modal-desc').textContent = dish.description || '—';
        document.getElementById('dish-modal-composition').textContent = dish.composition || dish.description || '—';
        document.getElementById('dish-modal-price').textContent = money(dish.price_cents);
        const imgEl = document.getElementById('dish-modal-img');
        const gallery = Array.isArray(dish.images) && dish.images.length > 0
            ? dish.images
            : [dish.image_url || PLACEHOLDER];
        imgEl.src = gallery[0] || PLACEHOLDER;
        imgEl.alt = dish.name;
        renderDishThumbs(gallery);
        dishModalAdd.disabled = !dish.is_available;
        dishModalAdd.textContent = dish.is_available ? 'В корзину' : 'Недоступно';
        setDishModalOpen(true);
    }

    function renderDishThumbs(images) {
        const thumbs = document.getElementById('dish-modal-thumbs');
        thumbs.innerHTML = '';
        images.forEach((src, idx) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'dish-modal__thumb' + (idx === 0 ? ' is-active' : '');
            b.innerHTML = `<img src="${escapeAttr(src)}" alt="">`;
            b.addEventListener('click', () => {
                document.getElementById('dish-modal-img').src = src;
                thumbs.querySelectorAll('.dish-modal__thumb').forEach(x => x.classList.remove('is-active'));
                b.classList.add('is-active');
            });
            thumbs.appendChild(b);
        });
    }

    dishModalClose.addEventListener('click', () => setDishModalOpen(false));
    dishModalBackdrop.addEventListener('click', () => setDishModalOpen(false));
    dishModalAdd.addEventListener('click', () => {
        if (!modalDish || !modalDish.is_available) return;
        addToCart(modalDish.id, modalDish.name, modalDish.price_cents);
        setDishModalOpen(false);
    });

    function addToCart(id, name, price_cents) {
        const cur = cart.get(id) || { id, name, price_cents, qty: 0 };
        cur.qty += 1;
        cart.set(id, cur);
        renderCart();
        const badge = document.getElementById('cart-badge');
        badge.classList.remove('pop');
        void badge.offsetWidth;
        badge.classList.add('pop');
    }

    function applyCheckoutPrefs(data) {
        const nameEl = document.getElementById('cust-name');
        const phoneEl = document.getElementById('cust-phone');
        const addrEl = document.getElementById('cust-addr');
        const comEl = document.getElementById('cust-comment');
        if (!data || typeof data !== 'object') return;
        if (data.customer_name) nameEl.value = data.customer_name;
        if (data.phone) {
            const d = digitsRuPhone(String(data.phone));
            phoneEl.value = d.length === 11 ? formatRuPhoneMask(d) : String(data.phone);
        }
        if (data.address) {
            addrEl.value = data.address;
            geocodeAddress();
        }
        if (data.comment) comEl.value = data.comment;
    }

    async function loadCheckoutPrefs() {
        if (loggedInUserId) {
            try {
                const r = await fetch(api('api/v1/me/delivery-prefs'), fetchCf);
                const j = await r.json();
                if (j.success && j.data) {
                    applyCheckoutPrefs(j.data);
                    return;
                }
            } catch (e) { /* ignore */ }
        }
        try {
            const raw = localStorage.getItem(LS_CHECKOUT);
            if (raw) applyCheckoutPrefs(JSON.parse(raw));
        } catch (e) { /* ignore */ }
    }

    document.getElementById('cart-clear').addEventListener('click', () => {
        if (cart.size === 0) return;
        cart.clear();
        renderCart();
    });

    let cardIndex = 0;

    async function loadMenu() {
        const el = document.getElementById('menu');
        try {
            const r = await fetch(api('api/v1/menu'), fetchCf);
            const j = await r.json();
            if (!j.success) throw new Error(j.error?.message || 'Ошибка');
            const cats = j.data.categories || [];
            cardIndex = 0;
            el.innerHTML = cats.map(c => `
                <section style="margin-bottom:2.25rem">
                    <h3 class="section-title" style="margin-top:0">${escapeHtml(c.name)}</h3>
                    <div class="menu-grid">
                        ${(c.dishes || []).map(d => {
                            const delay = (cardIndex++ * 0.045).toFixed(3) + 's';
                            const img = d.image_url ? escapeAttr(d.image_url) : PLACEHOLDER;
                            dishById.set(d.id, d);
                            const comp = escapeAttr(d.composition || d.description || '');
                            const desc = escapeAttr(d.description || '');
                            return `
                            <article class="dish-card" style="--d:${delay}" tabindex="0" role="button"
                                     data-dish-id="${d.id}" data-dish-name="${escapeAttr(d.name)}"
                                     data-dish-desc="${desc}" data-dish-composition="${comp}"
                                     data-dish-price="${d.price_cents}" data-dish-available="${d.is_available ? '1' : '0'}"
                                     data-dish-img="${img}" aria-label="Подробнее: ${escapeAttr(d.name)}">
                                <div class="dish-card__img">
                                    <img src="${img}" alt="" width="640" height="480" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                                </div>
                                <div class="dish-card__body">
                                    <h4 class="dish-name">${escapeHtml(d.name)}</h4>
                                    <p class="dish-desc">${escapeHtml((d.description || '').slice(0, 72))}${(d.description || '').length > 72 ? '…' : ''}</p>
                                    <div class="dish-row">
                                        <span class="price">${money(d.price_cents)}</span>
                                        <button type="button" class="btn-add" data-add="${d.id}" data-price="${d.price_cents}" ${d.is_available ? '' : 'disabled'}>В корзину</button>
                                    </div>
                                </div>
                            </article>`;
                        }).join('')}
                    </div>
                </section>
            `).join('');

            el.querySelectorAll('.btn-add').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const t = e.currentTarget;
                    const id = parseInt(t.getAttribute('data-add'), 10);
                    const price = parseInt(t.getAttribute('data-price'), 10);
                    const card = t.closest('.dish-card');
                    const name = card.querySelector('.dish-name').textContent;
                    addToCart(id, name, price);
                });
            });

            el.querySelectorAll('.dish-card').forEach(card => {
                const open = () => {
                    const id = parseInt(card.getAttribute('data-dish-id'), 10);
                    const fromMap = dishById.get(id);
                    if (fromMap) {
                        openDishModal(fromMap);
                        return;
                    }
                    openDishModal({
                        id,
                        name: card.getAttribute('data-dish-name') || '',
                        description: card.getAttribute('data-dish-desc') || '',
                        composition: card.getAttribute('data-dish-composition') || '',
                        price_cents: parseInt(card.getAttribute('data-dish-price'), 10) || 0,
                        is_available: card.getAttribute('data-dish-available') === '1',
                        image_url: card.getAttribute('data-dish-img') || ''
                    });
                };
                card.addEventListener('click', open);
                card.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        open();
                    }
                });
            });
        } catch (e) {
            el.innerHTML = '<p class="load-state">Не удалось загрузить меню: ' + escapeHtml(e.message) + '</p>';
        }
    }

    function renderCart() {
        const lines = document.getElementById('cart-lines');
        const totalEl = document.getElementById('cart-total');
        const badge = document.getElementById('cart-badge');
        const btnClear = document.getElementById('cart-clear');
        let count = 0;
        cart.forEach((v) => { count += v.qty; });
        badge.textContent = String(count);
        btnClear.disabled = cart.size === 0;

        if (cart.size === 0) {
            lines.innerHTML = '<p style="color:var(--muted);margin:0;font-size:0.88rem;">Пока пусто — добавьте блюда из меню</p>';
            totalEl.textContent = '';
            return;
        }
        let sum = 0;
        lines.innerHTML = '';
        cart.forEach((v) => {
            const line = v.price_cents * v.qty;
            sum += line;
            const div = document.createElement('div');
            div.className = 'cart-line';
            div.innerHTML = `<span>${escapeHtml(v.name)} × ${v.qty}</span><span>${money(line)}</span>`;
            lines.appendChild(div);
        });
        const fee = selectedZone ? Number(selectedZone.delivery_fee_cents || 0) : 0;
        const total = sum + fee;
        const zoneHint = selectedZone
            ? `\nДоставка (${escapeHtml(selectedZone.name)}): ${money(fee)}`
            : '';
        totalEl.innerHTML = `Товары: ${money(sum)}${zoneHint ? '<br>' + zoneHint : ''}<br>Итого: ${money(total)}`;
    }

    async function loadZones() {
        const el = document.getElementById('zones');
        try {
            const r = await fetch(api('api/v1/delivery-zones'), fetchCf);
            const j = await r.json();
            if (!j.success) throw new Error(j.error?.message || 'Ошибка');
            const zones = j.data.zones || [];
            zonesState = zones;
            selectedZone = zones[0] || null;
            deliveryZoneSelect.innerHTML = zones.map((z, i) =>
                `<option value="${z.id}" ${i === 0 ? 'selected' : ''}>${escapeHtml(z.name)} · ${money(z.delivery_fee_cents)}</option>`
            ).join('');
            deliveryZoneSelect.addEventListener('change', () => {
                const zid = parseInt(deliveryZoneSelect.value, 10);
                selectedZone = zonesState.find(z => Number(z.id) === zid) || zonesState[0] || null;
                renderCart();
            });
            el.innerHTML = zones.map((z, i) =>
                `<div class="zone-card" style="--dz:${(i * 0.06).toFixed(2)}s"><strong>${escapeHtml(z.name)}</strong>мин. заказ ${money(z.min_order_cents)} · доставка ${money(z.delivery_fee_cents)}</div>`
            ).join('');
            renderCart();
        } catch (e) {
            el.innerHTML = '<div class="load-state">' + escapeHtml(e.message) + '</div>';
        }
    }

    document.getElementById('submit-order').addEventListener('click', async () => {
        const msg = document.getElementById('order-msg');
        msg.textContent = '';
        msg.className = 'msg';
        const items = [];
        cart.forEach((v) => items.push({ dish_id: v.id, quantity: v.qty }));
        const phone = phoneForApi(phoneInput.value);
        if (!phone) {
            msg.className = 'msg err';
            msg.textContent = 'Введите номер телефона полностью (+7 и 10 цифр).';
            phoneInput.focus();
            return;
        }
        const body = {
            customer_name: document.getElementById('cust-name').value.trim(),
            phone,
            address: document.getElementById('cust-addr').value.trim(),
            comment: document.getElementById('cust-comment').value.trim(),
            delivery_zone_id: selectedZone ? Number(selectedZone.id) : null,
            address_lat: addressLat,
            address_lng: addressLng,
            items
        };
        let subtotal = 0;
        cart.forEach((v) => { subtotal += v.price_cents * v.qty; });
        if (selectedZone && subtotal < Number(selectedZone.min_order_cents || 0)) {
            msg.className = 'msg err';
            msg.textContent = 'Минимальный заказ для зоны "' + selectedZone.name + '" — ' + money(selectedZone.min_order_cents) + '.';
            return;
        }
        try {
            const r = await fetch(api('api/v1/orders'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify(body)
            });
            const j = await r.json();
            if (!j.success) {
                msg.className = 'msg err';
                msg.textContent = j.error?.message || 'Ошибка';
                return;
            }
            if (loggedInUserId) {
                window.location.href = api('profile') + '#orders';
                return;
            }
            msg.className = 'msg ok';
            msg.textContent = 'Заказ №' + j.data.id + ' оформлен. Войдите в профиль, чтобы отслеживать доставку.';
            try {
                localStorage.setItem(LS_CHECKOUT, JSON.stringify({
                    customer_name: body.customer_name,
                    phone: body.phone,
                    address: body.address,
                    comment: body.comment
                }));
            } catch (e) { /* ignore */ }
            cart.clear();
            renderCart();
            setCartOpen(false);
        } catch (e) {
            msg.className = 'msg err';
            msg.textContent = e.message;
        }
    });

    loadMenu();
    loadZones();
    renderCart();
    loadCheckoutPrefs();
})();
</script>
</body>
</html>

<?php
declare(strict_types=1);

/** @var array<string,mixed> $user */
/** @var list<array<string,mixed>>|null $orderHistory */
/** @var array<string,mixed>|null $activeOrder */
/** @var string|null $profileFlashOk */
/** @var string|null $profileFlashErr */
/** @var string $tgBotUsername */
/** @var bool $vkEnabled */
/** @var bool $yandexEnabled */
/** @var bool $hasPassword */

function ph(?string $v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$url = static fn (string $path): string => ($base === '' ? '' : $base) . '/' . ltrim($path, '/');
$avatar = (string) ($user['avatar_url'] ?? '');
$accounts = $user['accounts'] ?? [];
$orderHistory = (isset($orderHistory) && is_array($orderHistory)) ? $orderHistory : [];
$activeOrder = (isset($activeOrder) && is_array($activeOrder)) ? $activeOrder : null;
$linked = [];
foreach (is_array($accounts) ? $accounts : [] as $a) {
    $p = (string) ($a['provider'] ?? '');
    if ($p !== '') {
        $linked[$p] = $a;
    }
}
$statusRu = static fn (string $s): string => OrderStatus::labelRu($s);
$canCancel = static fn (string $s): bool => OrderStatus::canClientCancel($s);
$fmtRub = static fn (int $cents): string => number_format($cents / 100, 0, ',', ' ') . ' ₽';
$flashOk = is_string($profileFlashOk ?? null) ? $profileFlashOk : '';
$flashErr = is_string($profileFlashErr ?? null) ? $profileFlashErr : '';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Личный кабинет — FreshDrop</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #06070c;
            --surface: rgba(255,255,255,.05);
            --stroke: rgba(255,255,255,.1);
            --text: #f0f2f5;
            --muted: #9aa3b2;
            --cyan: #22d3ee;
            --vio: #7c5cff;
            --ok: #34d399;
            --err: #fb7185;
            --radius: 18px;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: "DM Sans", system-ui, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.5;
        }
        .bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            background:
                radial-gradient(ellipse 80% 50% at 10% -10%, rgba(124,92,255,.35), transparent 50%),
                radial-gradient(ellipse 60% 40% at 90% 10%, rgba(34,211,238,.18), transparent 45%),
                radial-gradient(ellipse 70% 50% at 50% 100%, rgba(124,92,255,.08), transparent 55%);
            pointer-events: none;
        }
        .wrap {
            position: relative;
            z-index: 1;
            max-width: 920px;
            margin: 0 auto;
            padding: 1.25rem 1rem 2.5rem;
        }
        .flash {
            padding: .75rem 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            font-size: .9rem;
        }
        .flash.ok { background: rgba(52,211,153,.12); border: 1px solid rgba(52,211,153,.35); color: var(--ok); }
        .flash.err { background: rgba(251,113,133,.1); border: 1px solid rgba(251,113,133,.35); color: var(--err); }
        .hero {
            border-radius: 24px;
            padding: 1.5rem 1.35rem;
            background: linear-gradient(135deg, rgba(124,92,255,.2), rgba(34,211,238,.08));
            border: 1px solid var(--stroke);
            margin-bottom: 1rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 1.25rem;
            box-shadow: 0 20px 60px rgba(0,0,0,.35);
        }
        .hero-avatar {
            position: relative;
            width: 96px;
            height: 96px;
            flex-shrink: 0;
        }
        .hero-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255,255,255,.2);
            box-shadow: 0 8px 32px rgba(0,0,0,.4);
        }
        .hero-text h1 {
            margin: 0 0 .25rem;
            font-size: 1.45rem;
            font-weight: 700;
            letter-spacing: -.02em;
        }
        .hero-text p {
            margin: 0;
            color: var(--muted);
            font-size: .88rem;
        }
        .hero-actions {
            margin-left: auto;
            display: flex;
            gap: .5rem;
            flex-wrap: wrap;
        }
        .btn {
            border: 1px solid var(--stroke);
            background: var(--surface);
            color: var(--text);
            padding: .5rem .85rem;
            border-radius: 11px;
            font: inherit;
            font-size: .82rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: .35rem;
            transition: background .2s, border-color .2s;
        }
        .btn:hover { background: rgba(255,255,255,.1); border-color: rgba(255,255,255,.18); }
        .btn-primary {
            background: linear-gradient(135deg, var(--vio), #5b8cff);
            border-color: transparent;
            color: #fff;
        }
        .btn-primary:hover { filter: brightness(1.06); }
        .tabs {
            display: flex;
            gap: .35rem;
            flex-wrap: wrap;
            margin-bottom: .75rem;
            padding: .35rem;
            background: var(--surface);
            border-radius: 14px;
            border: 1px solid var(--stroke);
        }
        .tabs button {
            border: none;
            background: transparent;
            color: var(--muted);
            padding: .55rem .9rem;
            border-radius: 10px;
            font: inherit;
            font-size: .84rem;
            font-weight: 600;
            cursor: pointer;
            transition: color .2s, background .2s;
        }
        .tabs button:hover { color: var(--text); }
        .tabs button.active {
            background: rgba(255,255,255,.1);
            color: var(--text);
            box-shadow: 0 2px 12px rgba(0,0,0,.2);
        }
        .panel {
            display: none;
            animation: fadeIn .35s ease;
        }
        .panel.active { display: block; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to { opacity: 1; transform: none; }
        }
        .card {
            background: var(--surface);
            border: 1px solid var(--stroke);
            border-radius: var(--radius);
            padding: 1.15rem 1.2rem;
            margin-bottom: 1rem;
        }
        .card h2 {
            margin: 0 0 .75rem;
            font-size: .95rem;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
            color: var(--muted);
        }
        label {
            display: block;
            font-size: .72rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .06em;
            color: var(--muted);
            margin-bottom: .35rem;
        }
        input[type="text"], input[type="email"], input[type="password"], input[type="tel"], input[type="url"], textarea {
            width: 100%;
            padding: .65rem .8rem;
            border-radius: 11px;
            border: 1px solid var(--stroke);
            background: rgba(0,0,0,.28);
            color: var(--text);
            font: inherit;
            margin-bottom: .75rem;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: rgba(124,92,255,.45);
            box-shadow: 0 0 0 3px rgba(124,92,255,.12);
        }
        textarea { min-height: 72px; resize: vertical; }
        .hint { font-size: .8rem; color: var(--muted); margin: -.4rem 0 .75rem; }
        .row-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: .75rem;
        }
        @media (max-width: 640px) {
            .row-2 { grid-template-columns: 1fr; }
            .hero-actions { margin-left: 0; width: 100%; }
        }
        .submit-line { margin-top: .25rem; }
        .avatar-drop {
            position: relative;
            min-height: 220px;
            border: 2px dashed rgba(255,255,255,.22);
            border-radius: 20px;
            background: linear-gradient(165deg, rgba(124,92,255,.08), rgba(34,211,238,.04));
            transition: border-color .25s, background .25s, transform .2s, box-shadow .25s;
            overflow: hidden;
        }
        .avatar-drop:hover {
            border-color: rgba(124,92,255,.45);
            box-shadow: 0 0 0 1px rgba(124,92,255,.15), 0 16px 48px rgba(0,0,0,.25);
        }
        .avatar-drop.avatar-drop--drag {
            border-color: rgba(34,211,238,.65);
            background: linear-gradient(165deg, rgba(124,92,255,.14), rgba(34,211,238,.1));
            transform: scale(1.01);
            box-shadow: 0 0 0 2px rgba(34,211,238,.2), 0 20px 56px rgba(34,211,238,.08);
        }
        .avatar-drop__input {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
            z-index: 4;
            font-size: 0;
        }
        .avatar-drop__face {
            position: relative;
            z-index: 1;
            pointer-events: none;
            padding: 1.75rem 1.25rem 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: .65rem;
        }
        .avatar-drop__ring {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: rgba(0,0,0,.35);
            border: 3px solid rgba(255,255,255,.12);
            display: grid;
            place-items: center;
            overflow: hidden;
            box-shadow: inset 0 2px 20px rgba(0,0,0,.35), 0 8px 28px rgba(124,92,255,.2);
        }
        .avatar-drop__ring img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .avatar-drop__ring--has-preview .ico-upload { display: none; }
        .avatar-drop__ring .ico-upload {
            width: 44px;
            height: 44px;
            opacity: .55;
            color: var(--cyan);
        }
        .avatar-drop__title {
            margin: 0;
            font-size: 1rem;
            font-weight: 700;
            letter-spacing: -.02em;
        }
        .avatar-drop__sub {
            margin: 0;
            font-size: .8rem;
            color: var(--muted);
            max-width: 280px;
            line-height: 1.45;
        }
        .avatar-drop__filename {
            font-size: .78rem;
            color: var(--cyan);
            font-weight: 600;
            min-height: 1.2em;
        }
        .avatar-drop + .submit-line {
            margin-top: 1rem;
            display: flex;
            gap: .5rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .btn-ghost {
            background: transparent;
            border-color: var(--stroke);
            color: var(--muted);
        }
        .btn-ghost:hover { color: var(--text); border-color: rgba(255,255,255,.2); }
        .link-grid {
            display: grid;
            gap: .65rem;
        }
        @media (min-width: 560px) {
            .link-grid { grid-template-columns: repeat(3, 1fr); }
        }
        .link-card {
            border: 1px solid var(--stroke);
            border-radius: 14px;
            padding: 1rem;
            background: rgba(0,0,0,.2);
            display: flex;
            flex-direction: column;
            gap: .65rem;
            min-height: 140px;
        }
        .link-card.linked { border-color: rgba(52,211,153,.35); }
        .link-card .top {
            display: flex;
            align-items: center;
            gap: .6rem;
        }
        .link-card img.ico { width: 32px; height: 32px; border-radius: 8px; }
        .link-card strong { font-size: .95rem; }
        .link-card .sub { font-size: .78rem; color: var(--muted); flex: 1; }
        .tg-slot { min-height: 40px; display: flex; align-items: center; }
        .orders-list details {
            border: 1px solid var(--stroke);
            border-radius: 12px;
            margin-bottom: .5rem;
            overflow: hidden;
        }
        .orders-list summary {
            cursor: pointer;
            list-style: none;
            padding: .65rem .75rem;
            background: rgba(255,255,255,.03);
            display: flex;
            flex-wrap: wrap;
            gap: .35rem 1rem;
            font-size: .88rem;
        }
        .orders-list summary::-webkit-details-marker { display: none; }
        .orders-list .body {
            padding: .6rem .75rem .85rem;
            font-size: .85rem;
            color: var(--muted);
            border-top: 1px solid var(--stroke);
        }
        .orders-list ul { margin: .35rem 0 0; padding-left: 1.1rem; }
        .btn-cancel-order {
            margin-top: .65rem;
            border-color: rgba(251,113,133,.4);
            color: var(--err);
            background: rgba(251,113,133,.08);
        }
        .btn-cancel-order:hover { background: rgba(251,113,133,.15); }

        .active-order {
            border-color: rgba(34,211,238,.35);
            background: linear-gradient(135deg, rgba(124,92,255,.12), rgba(34,211,238,.06));
        }
        .active-order h2 { color: var(--cyan); }
        #active-order-map {
            height: 200px;
            border-radius: 14px;
            border: 1px solid var(--stroke);
            margin: .75rem 0;
            overflow: hidden;
        }
        .delivery-steps {
            display: grid;
            gap: .45rem;
            margin: .75rem 0;
        }
        .delivery-step {
            display: flex;
            align-items: center;
            gap: .55rem;
            padding: .5rem .65rem;
            border-radius: 10px;
            border: 1px solid var(--stroke);
            background: rgba(0,0,0,.2);
            font-size: .88rem;
            color: var(--muted);
        }
        .delivery-step.done { color: var(--ok); border-color: rgba(52,211,153,.35); }
        .delivery-step.active {
            color: var(--text);
            border-color: rgba(34,211,238,.45);
            background: rgba(34,211,238,.08);
            font-weight: 600;
        }
        .delivery-step__dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255,255,255,.2);
            flex-shrink: 0;
        }
        .delivery-step.done .delivery-step__dot { background: var(--ok); }
        .delivery-step.active .delivery-step__dot {
            background: var(--cyan);
            box-shadow: 0 0 10px var(--cyan);
        }
        .eta-line { font-size: .85rem; color: var(--muted); margin: 0; }
    </style>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
</head>
<body>
<div class="bg" aria-hidden="true"></div>
<div class="wrap">
    <?php if ($flashOk !== ''): ?>
        <div class="flash ok"><?= ph($flashOk) ?></div>
    <?php endif; ?>
    <?php if ($flashErr !== ''): ?>
        <div class="flash err"><?= ph($flashErr) ?></div>
    <?php endif; ?>

    <div class="hero">
        <div class="hero-avatar">
            <img src="<?= ph($avatar !== '' ? $avatar : 'data:image/svg+xml,' . rawurlencode('<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" fill="#1a1d2e"/></svg>')) ?>" alt="">
        </div>
        <div class="hero-text">
            <h1><?= ph((string) ($user['display_name'] ?? 'Профиль')) ?></h1>
            <p>
                ID <?= (int) ($user['id'] ?? 0) ?>
                <?php if (!empty($user['email'])): ?> · <?= ph((string) $user['email']) ?><?php endif; ?>
                <br>Последний вход: <?= ph((string) ($user['last_login_at'] ?? '')) ?>
            </p>
        </div>
        <div class="hero-actions">
            <a class="btn" href="<?= ph($url('/')) ?>">← На сайт</a>
            <form method="post" action="<?= ph($url('/auth/logout')) ?>" style="margin:0;">
                <button class="btn" type="submit">Выйти</button>
            </form>
        </div>
    </div>

    <div class="tabs" role="tablist">
        <button type="button" class="active" data-tab="overview" role="tab" aria-selected="true">Обзор</button>
        <button type="button" data-tab="settings" role="tab" id="tab-settings">Профиль и аватар</button>
        <button type="button" data-tab="delivery" role="tab">Доставка</button>
        <button type="button" data-tab="linked" role="tab" id="tab-linked">Связи</button>
        <button type="button" data-tab="security" role="tab" id="tab-security">Пароль</button>
        <button type="button" data-tab="orders" role="tab">Мои заказы</button>
    </div>

    <div id="panel-overview" class="panel active" role="tabpanel">
        <div class="card">
            <h2>Сводка</h2>
            <p style="margin:0;color:var(--muted);font-size:.9rem;">
                Управляйте данными, аватаром, адресом доставки и привязкой соцсетей во вкладках выше.
                Оформляя заказ на главной, сохранённые контакты подставятся автоматически.
            </p>
        </div>
    </div>

    <div id="panel-settings" class="panel" role="tabpanel">
        <div class="card">
            <h2>Имя, почта, ссылка на аватар</h2>
            <form method="post" action="<?= ph($url('/profile/settings')) ?>">
                <label for="display_name">Отображаемое имя</label>
                <input id="display_name" name="display_name" type="text" required
                       value="<?= ph((string) ($user['display_name'] ?? '')) ?>" autocomplete="name">
                <label for="email">Почта (для входа и уведомлений)</label>
                <input id="email" name="email" type="email" value="<?= ph((string) ($user['email'] ?? '')) ?>" autocomplete="email">
                <p class="hint">Пустое поле — не менять текущую почту. При смене проверяется уникальность.</p>
                <label for="avatar_url">URL картинки аватара (необязательно)</label>
                <input id="avatar_url" name="avatar_url" type="url" placeholder="https://…"
                       value="<?= ph((string) ($user['avatar_url'] ?? '')) ?>">
                <p class="hint">Или загрузите файл ниже — он имеет приоритет при отображении после сохранения ссылки не требуется.</p>
                <div class="submit-line">
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                </div>
            </form>
        </div>
        <div class="card">
            <h2>Загрузить аватар</h2>
            <p class="hint" style="margin-top:0">JPG, PNG, WebP или GIF, до ~2,5 МБ. Можно перетащить файл в область ниже.</p>
            <form method="post" action="<?= ph($url('/profile/avatar')) ?>" enctype="multipart/form-data" id="form-avatar-upload">
                <div class="avatar-drop" id="avatar-drop">
                    <input id="avatar_file" name="avatar" class="avatar-drop__input" type="file"
                           accept="image/jpeg,image/png,image/webp,image/gif" required
                           aria-label="Выбрать изображение для аватара">
                    <div class="avatar-drop__face">
                        <div class="avatar-drop__ring" id="avatar_ring" aria-hidden="true">
                            <img id="avatar_preview" class="avatar-drop__preview-img" alt="Предпросмотр аватара" width="120" height="120" hidden>
                            <svg class="ico-upload" id="avatar_ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">
                                <path d="M12 16V4m0 0l4 4m-4-4L8 8"/>
                                <path d="M4 14.5A2.5 2.5 0 016.5 12H7a5 5 0 0010 0h.5a2.5 2.5 0 012.5 2.5V19a2 2 0 01-2 2H6a2 2 0 01-2-2v-2.5z"/>
                            </svg>
                        </div>
                        <p class="avatar-drop__title">Перетащите фото сюда</p>
                        <p class="avatar-drop__sub">или нажмите на область, чтобы открыть галерею</p>
                        <span class="avatar-drop__filename" id="avatar_filename"></span>
                    </div>
                </div>
                <div class="submit-line">
                    <button type="submit" class="btn btn-primary" id="avatar_submit">Загрузить на сервер</button>
                    <button type="button" class="btn btn-ghost" id="avatar_clear" hidden>Сбросить выбор</button>
                </div>
            </form>
        </div>
    </div>

    <div id="panel-delivery" class="panel" role="tabpanel">
        <div class="card">
            <h2>Данные для доставки</h2>
            <form method="post" action="<?= ph($url('/profile/settings')) ?>">
                <input type="hidden" name="display_name" value="<?= ph((string) ($user['display_name'] ?? '')) ?>">
                <input type="hidden" name="email" value="<?= ph((string) ($user['email'] ?? '')) ?>">
                <input type="hidden" name="avatar_url" value="<?= ph((string) ($user['avatar_url'] ?? '')) ?>">
                <label for="saved_delivery_name">Имя получателя</label>
                <input id="saved_delivery_name" name="saved_delivery_name" type="text"
                       value="<?= ph((string) ($user['saved_delivery_name'] ?? '')) ?>" autocomplete="name">
                <label for="saved_delivery_phone">Телефон</label>
                <input id="saved_delivery_phone" name="saved_delivery_phone" type="tel" class="js-phone"
                       value="<?= ph((string) ($user['saved_delivery_phone'] ?? '')) ?>" placeholder="+7 (999) 000-00-00" autocomplete="tel" maxlength="18">
                <label for="saved_delivery_address">Адрес</label>
                <textarea id="saved_delivery_address" name="saved_delivery_address" autocomplete="street-address"><?= ph((string) ($user['saved_delivery_address'] ?? '')) ?></textarea>
                <label for="saved_delivery_comment">Комментарий курьеру</label>
                <input id="saved_delivery_comment" name="saved_delivery_comment" type="text"
                       value="<?= ph((string) ($user['saved_delivery_comment'] ?? '')) ?>">
                <div class="submit-line">
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                </div>
            </form>
        </div>
    </div>

    <div id="panel-linked" class="panel" role="tabpanel">
        <div class="card">
            <h2>Привязка аккаунтов</h2>
            <p class="hint" style="margin-top:0">Войдите через выбранный сервис — он будет привязан к текущему профилю. Нельзя привязать аккаунт, который уже занят другим пользователем.</p>
            <div class="link-grid">
                <div class="link-card<?= isset($linked['telegram']) ? ' linked' : '' ?>">
                    <div class="top">
                        <img class="ico" src="https://cdn.simpleicons.org/telegram/26A5E4" alt="">
                        <strong>Telegram</strong>
                    </div>
                    <div class="sub">
                        <?php if (isset($linked['telegram'])): ?>
                            @<?= ph((string) ($linked['telegram']['username'] ?? 'привязан')) ?>
                        <?php else: ?>
                            Не привязан
                        <?php endif; ?>
                    </div>
                    <div class="tg-slot">
                        <?php if ($tgBotUsername !== ''): ?>
                            <script async src="https://telegram.org/js/telegram-widget.js?22"
                                    data-telegram-login="<?= ph($tgBotUsername) ?>"
                                    data-size="medium" data-userpic="false" data-request-access="write"
                                    data-onauth="freshdropProfileTg(user)"></script>
                        <?php else: ?>
                            <span class="hint">Настройте бота в config</span>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($linked['telegram'])): ?>
                        <form method="post" action="<?= ph($url('/profile/unlink-social')) ?>" onsubmit="return confirm('Отвязать Telegram?');">
                            <input type="hidden" name="provider" value="telegram">
                            <button type="submit" class="btn">Отвязать</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="link-card<?= isset($linked['vk']) ? ' linked' : '' ?>">
                    <div class="top">
                        <img class="ico" src="https://cdn.simpleicons.org/vk/0077FF" alt="">
                        <strong>ВКонтакте</strong>
                    </div>
                    <div class="sub">
                        <?php if (isset($linked['vk'])): ?>
                            <?= ph((string) ($linked['vk']['username'] ?: 'привязан')) ?>
                        <?php else: ?>
                            Не привязан
                        <?php endif; ?>
                    </div>
                    <?php if ($vkEnabled): ?>
                        <a class="btn btn-primary" href="<?= ph(isset($linked['vk']) ? '#' : $url('/auth/vk')) ?>"
                           <?= isset($linked['vk']) ? 'style="opacity:.5;pointer-events:none"' : '' ?>>
                            <?= isset($linked['vk']) ? 'Уже привязано' : 'Подключить ВК' ?>
                        </a>
                    <?php else: ?>
                        <span class="hint">OAuth не настроен</span>
                    <?php endif; ?>
                    <?php if (isset($linked['vk'])): ?>
                        <form method="post" action="<?= ph($url('/profile/unlink-social')) ?>" onsubmit="return confirm('Отвязать VK?');">
                            <input type="hidden" name="provider" value="vk">
                            <button type="submit" class="btn">Отвязать</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="link-card<?= isset($linked['yandex']) ? ' linked' : '' ?>">
                    <div class="top">
                        <img class="ico" src="https://cdn.simpleicons.org/yandex/FC3F1D" alt="">
                        <strong>Яндекс</strong>
                    </div>
                    <div class="sub">
                        <?php if (isset($linked['yandex'])): ?>
                            <?= ph((string) ($linked['yandex']['username'] ?: ($linked['yandex']['email'] ?? 'привязан'))) ?>
                        <?php else: ?>
                            Не привязан
                        <?php endif; ?>
                    </div>
                    <?php if ($yandexEnabled): ?>
                        <a class="btn btn-primary" href="<?= ph(isset($linked['yandex']) ? '#' : $url('/auth/yandex')) ?>"
                           <?= isset($linked['yandex']) ? 'style="opacity:.5;pointer-events:none"' : '' ?>>
                            <?= isset($linked['yandex']) ? 'Уже привязано' : 'Подключить Яндекс' ?>
                        </a>
                    <?php else: ?>
                        <span class="hint">OAuth не настроен</span>
                    <?php endif; ?>
                    <?php if (isset($linked['yandex'])): ?>
                        <form method="post" action="<?= ph($url('/profile/unlink-social')) ?>" onsubmit="return confirm('Отвязать Яндекс?');">
                            <input type="hidden" name="provider" value="yandex">
                            <button type="submit" class="btn">Отвязать</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div id="panel-security" class="panel" role="tabpanel">
        <?php if ($hasPassword): ?>
            <div class="card">
                <h2>Сменить пароль</h2>
                <form method="post" action="<?= ph($url('/profile/password')) ?>">
                    <label for="current_password">Текущий пароль</label>
                    <input id="current_password" name="current_password" type="password" required autocomplete="current-password">
                    <label for="new_password">Новый пароль</label>
                    <input id="new_password" name="new_password" type="password" required autocomplete="new-password" minlength="6">
                    <div class="submit-line">
                        <button type="submit" class="btn btn-primary">Обновить пароль</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="card">
                <h2>Задать пароль для входа по почте</h2>
                <p class="hint" style="margin-top:0">Вы входите только через соцсети. Задайте пароль — сможете также войти по почте.</p>
                <form method="post" action="<?= ph($url('/profile/password/init')) ?>">
                    <label for="init_password">Новый пароль</label>
                    <input id="init_password" name="new_password" type="password" required autocomplete="new-password" minlength="6">
                    <div class="submit-line">
                        <button type="submit" class="btn btn-primary">Сохранить пароль</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div id="panel-orders" class="panel" role="tabpanel">
        <?php if ($activeOrder !== null): ?>
            <div class="card active-order" id="active-order-card">
                <h2>Активный заказ №<?= (int) ($activeOrder['id'] ?? 0) ?></h2>
                <p class="eta-line" id="active-order-eta">
                    <?php
                    $activeStatus = (string) ($activeOrder['status'] ?? '');
                    if ($activeStatus === 'received'): ?>
                        Заказ доставлен
                    <?php elseif ((int) ($activeOrder['eta_minutes'] ?? 0) > 0): ?>
                        Статус: <?= ph((string) ($activeOrder['status_label'] ?? '')) ?> · ~<?= (int) $activeOrder['eta_minutes'] ?> мин
                    <?php else: ?>
                        Статус: <?= ph((string) ($activeOrder['status_label'] ?? 'Готовят')) ?>
                    <?php endif; ?>
                </p>
                <div id="active-order-map" aria-label="Карта доставки"></div>
                <div class="delivery-steps" id="active-order-steps">
                    <?php foreach (($activeOrder['delivery_timeline'] ?? []) as $step): ?>
                        <?php
                        $cls = '';
                        if (!empty($step['active'])) {
                            $cls = ' active';
                        } elseif (!empty($step['done'])) {
                            $cls = ' done';
                        }
                        ?>
                        <div class="delivery-step<?= $cls ?>">
                            <span class="delivery-step__dot"></span>
                            <span><?= ph((string) ($step['label'] ?? '')) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="font-size:.88rem;color:var(--muted)">
                    <?= ph((string) ($activeOrder['address'] ?? '')) ?>
                </div>
                <?php if ($canCancel((string) ($activeOrder['status'] ?? ''))): ?>
                    <form method="post" action="<?= ph($url('/profile/orders/' . (int) ($activeOrder['id'] ?? 0) . '/cancel')) ?>"
                          style="margin-top:.65rem" onsubmit="return confirm('Отменить активный заказ?');">
                        <button type="submit" class="btn btn-cancel-order">Отменить заказ</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="card orders-list">
            <h2 id="order-history">История заказов</h2>
            <?php if ($orderHistory === []): ?>
                <p style="margin:0;color:var(--muted);font-size:.9rem;">Пока нет заказов с этого аккаунта.</p>
            <?php else: ?>
                <?php foreach ($orderHistory as $ord): ?>
                    <?php
                    /** @var array<string,mixed> $ord */
                    $items = $ord['items'] ?? [];
                    $sum = (int) ($ord['total_cents'] ?? 0);
                    ?>
                    <details>
                        <summary>
                            <strong>№<?= (int) ($ord['id'] ?? 0) ?></strong>
                            <span><?= ph((string) ($ord['created_at'] ?? '')) ?></span>
                            <span><?= ph($fmtRub($sum)) ?></span>
                            <span><?= ph($statusRu((string) ($ord['status'] ?? ''))) ?></span>
                        </summary>
                        <div class="body">
                            <div><?= ph((string) ($ord['address'] ?? '')) ?></div>
                            <?php if (is_array($items) && $items !== []): ?>
                                <ul>
                                    <?php foreach ($items as $it): ?>
                                        <li><?= ph((string) ($it['dish_name'] ?? '')) ?> × <?= (int) ($it['quantity'] ?? 0) ?> — <?= ph($fmtRub((int) ($it['price_cents'] ?? 0) * (int) ($it['quantity'] ?? 0))) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <?php if (!empty($ord['comment'])): ?>
                                <div style="margin-top:.4rem">Комментарий: <?= ph((string) $ord['comment']) ?></div>
                            <?php endif; ?>
                            <?php if ($canCancel((string) ($ord['status'] ?? ''))): ?>
                                <form method="post" action="<?= ph($url('/profile/orders/' . (int) ($ord['id'] ?? 0) . '/cancel')) ?>"
                                      style="margin-top:.65rem" onsubmit="return confirm('Отменить заказ №<?= (int) ($ord['id'] ?? 0) ?>?');">
                                    <button type="submit" class="btn btn-cancel-order">Отменить заказ</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </details>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
(function () {
    var tabs = document.querySelectorAll('.tabs [data-tab]');
    var panels = document.querySelectorAll('.panel');
    function show(id) {
        tabs.forEach(function (t) {
            var on = t.getAttribute('data-tab') === id;
            t.classList.toggle('active', on);
            t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        panels.forEach(function (p) {
            p.classList.toggle('active', p.id === 'panel-' + id);
        });
        history.replaceState(null, '', '#' + id);
    }
    tabs.forEach(function (t) {
        t.addEventListener('click', function () { show(t.getAttribute('data-tab')); });
    });
    var h = (location.hash || '').replace(/^#/, '');
    if (h === 'settings' || h === 'delivery' || h === 'linked' || h === 'security' || h === 'orders' || h === 'overview') {
        show(h);
    }
    window.addEventListener('hashchange', function () {
        var x = (location.hash || '').replace(/^#/, '');
        if (x === 'order-history') { show('orders'); return; }
        if (['settings','delivery','linked','security','orders','overview'].indexOf(x) >= 0) show(x);
    });

    function digitsRuPhone(raw) {
        var d = String(raw).replace(/\D/g, '');
        if (d.startsWith('8')) d = '7' + d.slice(1);
        if (d.length === 10 && d[0] === '9') d = '7' + d;
        if (d.length > 0 && d[0] !== '7') d = '7' + d.replace(/^7+/, '');
        return d.slice(0, 11);
    }
    function formatRuPhoneMask(digits) {
        if (digits.length <= 1) return '+7';
        var r = digits.slice(1);
        var o = '+7 (' + r.slice(0, Math.min(3, r.length));
        if (r.length <= 3) return o + (r.length === 3 ? ') ' : '');
        o += ') ' + r.slice(3, Math.min(6, r.length));
        if (r.length <= 6) return o;
        o += '-' + r.slice(6, Math.min(8, r.length));
        if (r.length <= 8) return o;
        return o + '-' + r.slice(8, 10);
    }
    document.querySelectorAll('.js-phone').forEach(function (input) {
        input.addEventListener('focus', function () { if (!input.value.trim()) input.value = '+7'; });
        input.addEventListener('blur', function () { if (digitsRuPhone(input.value).length <= 1) input.value = ''; });
        input.addEventListener('input', function () {
            input.value = formatRuPhoneMask(digitsRuPhone(input.value));
        });
    });

    (function initAvatarDrop() {
        var drop = document.getElementById('avatar-drop');
        var input = document.getElementById('avatar_file');
        var preview = document.getElementById('avatar_preview');
        var ring = document.getElementById('avatar_ring');
        var fname = document.getElementById('avatar_filename');
        var clearBtn = document.getElementById('avatar_clear');
        if (!drop || !input || !preview || !ring) return;

        function showPreview(file) {
            if (!file || !/^image\/(jpeg|png|gif|webp)$/i.test(file.type)) {
                return false;
            }
            var reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.hidden = false;
                ring.classList.add('avatar-drop__ring--has-preview');
                fname.textContent = file.name;
                if (clearBtn) clearBtn.hidden = false;
            };
            reader.readAsDataURL(file);
            return true;
        }

        input.addEventListener('change', function () {
            var f = input.files && input.files[0];
            if (f && !showPreview(f)) {
                fname.textContent = 'Выберите JPG, PNG, WebP или GIF';
                input.value = '';
            }
        });

        ['dragenter', 'dragover'].forEach(function (ev) {
            drop.addEventListener(ev, function (e) {
                e.preventDefault();
                e.stopPropagation();
                drop.classList.add('avatar-drop--drag');
            });
        });
        drop.addEventListener('dragleave', function (e) {
            e.preventDefault();
            if (!drop.contains(e.relatedTarget)) {
                drop.classList.remove('avatar-drop--drag');
            }
        });
        drop.addEventListener('drop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            drop.classList.remove('avatar-drop--drag');
            var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
            if (!f) return;
            if (!/^image\/(jpeg|png|gif|webp)$/i.test(f.type)) {
                fname.textContent = 'Нужен JPG, PNG, WebP или GIF';
                return;
            }
            try {
                var dt = new DataTransfer();
                dt.items.add(f);
                input.files = dt.files;
            } catch (err) {
                fname.textContent = 'Не удалось принять файл';
                return;
            }
            showPreview(f);
        });

        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                input.value = '';
                preview.src = '';
                preview.hidden = true;
                ring.classList.remove('avatar-drop__ring--has-preview');
                fname.textContent = '';
                clearBtn.hidden = true;
            });
        }
    })();
})();
function freshdropProfileTg(user) {
    fetch('<?= ph($url('/auth/telegram')) ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(user)
    })
    .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
    .then(function (x) {
        if (x.j && x.j.success) {
            window.location.href = x.j.data && x.j.data.redirect ? x.j.data.redirect : '<?= ph($url('/profile')) ?>#linked';
            return;
        }
        var msg = (x.j && x.j.error && x.j.error.message) ? x.j.error.message : (x.j && x.j.error && x.j.error.code === 'LINK_CONFLICT' ? 'Конфликт привязки' : 'Ошибка');
        alert(msg);
    })
    .catch(function () { alert('Ошибка сети'); });
}
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>
(function () {
    var baseDir = window.location.pathname.replace(/[^/]*$/, '');
    var api = function (path) { return window.location.origin + baseDir + path.replace(/^\//, ''); };
    var mapEl = document.getElementById('active-order-map');
    if (!mapEl || typeof L === 'undefined') return;

    var map = null;
    var marker = null;
    var RESTAURANT = [55.7558, 37.6173];

    function renderMap(lat, lng) {
        if (!map) {
            map = L.map('active-order-map', { zoomControl: true, attributionControl: false });
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
            L.marker(RESTAURANT).addTo(map).bindPopup('FreshDrop');
        }
        var p = [lat, lng];
        if (!marker) {
            marker = L.marker(p).addTo(map);
        } else {
            marker.setLatLng(p);
        }
        map.setView(p, 15);
        var bounds = L.latLngBounds([RESTAURANT, p]);
        map.fitBounds(bounds.pad(0.35));
    }

    function renderSteps(timeline) {
        var box = document.getElementById('active-order-steps');
        if (!box || !Array.isArray(timeline)) return;
        box.innerHTML = timeline.map(function (s) {
            var cls = s.active ? ' active' : (s.done ? ' done' : '');
            return '<div class="delivery-step' + cls + '"><span class="delivery-step__dot"></span><span>'
                + (s.label || '') + '</span></div>';
        }).join('');
    }

    function pollActive() {
        fetch(api('api/v1/me/orders/active'), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (!j.success) return;
                var o = j.data.order;
                if (!o) {
                    var card = document.getElementById('active-order-card');
                    if (card) card.remove();
                    return;
                }
                var eta = document.getElementById('active-order-eta');
                if (eta) {
                    if (o.status === 'received') {
                        eta.textContent = 'Заказ доставлен';
                    } else if (o.eta_minutes > 0) {
                        eta.textContent = 'Статус: ' + (o.status_label || o.status) + ' · ~' + o.eta_minutes + ' мин';
                    } else {
                        eta.textContent = 'Статус: ' + (o.status_label || 'Готовят');
                    }
                }
                renderSteps(o.delivery_timeline || []);
                if (o.address_lat != null && o.address_lng != null) {
                    renderMap(o.address_lat, o.address_lng);
                }
            })
            .catch(function () {});
    }

    <?php if ($activeOrder !== null && isset($activeOrder['address_lat'], $activeOrder['address_lng'])): ?>
    renderMap(<?= (float) $activeOrder['address_lat'] ?>, <?= (float) $activeOrder['address_lng'] ?>);
    <?php endif; ?>

    pollActive();
    setInterval(pollActive, 15000);
})();
</script>
</body>
</html>

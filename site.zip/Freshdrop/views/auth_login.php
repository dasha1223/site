<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход — FreshDrop</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { margin:0; min-height:100vh; font-family:"DM Sans",system-ui,sans-serif; background:#0a0b10; color:#e8eaef; display:grid; place-items:center; padding:1.25rem; }
        .card { width:min(420px,100%); border-radius:20px; padding:1.4rem 1.4rem 1.2rem; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.09); }
        h1 { margin:0 0 .35rem; font-size:1.35rem; }
        .lead { margin:0 0 1rem; color:#9aa3b2; font-size:.92rem; }
        .error { margin-bottom:.85rem; color:#fb7185; font-size:.9rem; }
        label { display:block; font-size:.82rem; color:#9aa3b2; margin-bottom:.35rem; }
        input[type="email"], input[type="password"], input[type="text"] {
            width:100%; padding:.65rem .75rem; border-radius:10px; border:1px solid rgba(255,255,255,.12);
            background:rgba(0,0,0,.25); color:#e8eaef; font:inherit;
        }
        input:focus { outline:none; border-color:rgba(34,211,238,.45); }
        .field { margin-bottom:.75rem; }
        .btn-primary {
            width:100%; margin-top:.25rem; padding:.78rem 1rem; border-radius:12px; border:none;
            background:linear-gradient(135deg,#22d3ee,#0ea5e9); color:#0a0b10; font-weight:700; font-size:.95rem; cursor:pointer;
        }
        .btn-primary:hover { filter:brightness(1.06); }
        .divider { margin:1.15rem 0 .85rem; display:flex; align-items:center; gap:.65rem; color:#6b7280; font-size:.78rem; text-transform:uppercase; letter-spacing:.04em; }
        .divider::before, .divider::after { content:""; flex:1; height:1px; background:rgba(255,255,255,.1); }
        .social-row { display:flex; justify-content:center; align-items:center; gap:1rem; flex-wrap:wrap; }
        .social-link {
            display:inline-flex; align-items:center; justify-content:center; width:52px; height:52px; border-radius:14px;
            background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.1); text-decoration:none; transition:background .15s;
        }
        .social-link:hover:not(.disabled) { background:rgba(255,255,255,.12); }
        .social-link.disabled { opacity:.38; cursor:not-allowed; pointer-events:none; }
        .social-link img { width:28px; height:28px; display:block; }
        #tg-wrap { min-height:44px; display:flex; justify-content:center; align-items:center; }
        .muted { font-size:.84rem; color:#9aa3b2; text-align:center; }
        details.reg { margin-top:1rem; border-top:1px solid rgba(255,255,255,.08); padding-top:.85rem; }
        details.reg[open] { border-top:none; margin-top:0; padding-top:0; }
        details.reg summary { cursor:pointer; color:#22d3ee; font-size:.88rem; list-style:none; user-select:none; }
        details.reg summary::-webkit-details-marker { display:none; }
        .reg-body { margin-top:.75rem; }
        .reg-body h1 { margin:0 0 .35rem; font-size:1.35rem; }
        .reg-body > .lead { margin-bottom:1rem; }
        .footer { margin-top:1rem; display:flex; justify-content:center; }
        a.link { color:#22d3ee; text-decoration:none; font-size:.88rem; }
        a.link:hover { text-decoration:underline; }
    </style>
</head>
<body>
<div class="card">
    <div id="login-section">
        <h1>Вход</h1>
        <p class="lead">Почта и пароль — основной способ входа.</p>

        <?php if (!empty($flashError)): ?>
            <div class="error"><?= htmlspecialchars((string) $flashError, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="post" action="<?= htmlspecialchars($this->url('/auth/email'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" autocomplete="on">
            <div class="field">
                <label for="email">Почта</label>
                <input id="email" name="email" type="email" required autocomplete="email" placeholder="you@example.com">
            </div>
            <div class="field">
                <label for="password">Пароль</label>
                <input id="password" name="password" type="password" required autocomplete="current-password" minlength="6">
            </div>
            <button type="submit" class="btn-primary">Войти</button>
        </form>

        <div class="divider">Альтернативный вход</div>
        <div class="social-row">
        <div id="tg-wrap">
            <?php if ($tgBotUsername !== ''): ?>
                <script async src="https://telegram.org/js/telegram-widget.js?22"
                        data-telegram-login="<?= htmlspecialchars($tgBotUsername, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>"
                        data-size="large"
                        data-userpic="false"
                        data-request-access="write"
                        data-onauth="freshdropTelegramAuth(user)"></script>
            <?php else: ?>
                <span class="social-link disabled" title="Настройте бота в config"><img src="https://cdn.simpleicons.org/telegram/26A5E4" alt="Telegram" width="28" height="28"></span>
            <?php endif; ?>
        </div>

        <?php if (!empty($vkEnabled)): ?>
            <a class="social-link" href="<?= htmlspecialchars($this->url('/auth/vk'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" title="ВКонтакте">
                <img src="https://cdn.simpleicons.org/vk/0077FF" alt="ВКонтакте" width="28" height="28">
            </a>
        <?php else: ?>
            <span class="social-link disabled" title="Настройте VK OAuth в config"><img src="https://cdn.simpleicons.org/vk/0077FF" alt="ВКонтакте" width="28" height="28"></span>
        <?php endif; ?>

        <?php if (!empty($yandexEnabled)): ?>
            <a class="social-link" href="<?= htmlspecialchars($this->url('/auth/yandex'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" title="Яндекс">
                <img src="https://cdn.simpleicons.org/yandex/FC3F1D" alt="Яндекс" width="28" height="28">
            </a>
        <?php else: ?>
            <span class="social-link disabled" title="Настройте Yandex OAuth в config"><img src="https://cdn.simpleicons.org/yandex/FC3F1D" alt="Яндекс" width="28" height="28"></span>
        <?php endif; ?>
        </div>
    </div>

    <details class="reg" id="reg-details">
        <summary>Регистрация по почте</summary>
        <div class="reg-body">
            <h1>Регистрация</h1>
            <p class="lead">Укажите почту и пароль для нового аккаунта.</p>
            <form method="post" action="<?= htmlspecialchars($this->url('/auth/register'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
                <div class="field">
                    <label for="reg-email">Почта</label>
                    <input id="reg-email" name="email" type="email" required autocomplete="email">
                </div>
                <div class="field">
                    <label for="reg-name">Имя (необязательно)</label>
                    <input id="reg-name" name="display_name" type="text" autocomplete="name" placeholder="Как к вам обращаться">
                </div>
                <div class="field">
                    <label for="reg-password">Пароль</label>
                    <input id="reg-password" name="password" type="password" required autocomplete="new-password" minlength="6">
                </div>
                <button type="submit" class="btn-primary">Создать аккаунт</button>
            </form>
        </div>
    </details>

    <div class="footer">
        <a class="link" href="<?= htmlspecialchars($this->url('/'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">← На главную</a>
    </div>
</div>
<script>
(function () {
    var details = document.getElementById('reg-details');
    var loginSection = document.getElementById('login-section');
    if (!details || !loginSection) return;
    var summary = details.querySelector('summary');
    var labelOpen = 'Регистрация по почте';
    var labelBack = '← Ко входу';
    details.addEventListener('toggle', function () {
        if (details.open) {
            loginSection.setAttribute('hidden', '');
            if (summary) summary.textContent = labelBack;
        } else {
            loginSection.removeAttribute('hidden');
            if (summary) summary.textContent = labelOpen;
        }
    });
})();
function freshdropTelegramAuth(user) {
    fetch('<?= htmlspecialchars($this->url('/auth/telegram'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    })
    .then(r => r.json())
    .then(j => {
        if (!j.success) {
            alert((j.error && j.error.message) ? j.error.message : 'Ошибка авторизации Telegram');
            return;
        }
        window.location.href = j.data.redirect || '<?= htmlspecialchars($this->url('/profile'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>';
    })
    .catch(() => alert('Ошибка сети при авторизации Telegram'));
}
</script>
</body>
</html>
